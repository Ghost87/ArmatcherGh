#!/usr/bin/env python3
"""
ARMATCHER Relay — VPS Customer Edition (GH)
===========================================

Auto-republish posts: Telegram source channel -> Bale + Rubika channels.

This edition runs 24/7 on a VPS (systemd), panel = bottom Reply-Keyboard,
three roles:

  * vendor      — hidden maintenance role, fingerprint-locked; also holds a
                  concealed /remoke off-switch (never mentioned in any text)
  * main admin  — the customer (MAIN_ADMIN_ID env): add channel-set (the plan
                  size is license-locked — the add button simply disappears; it is
                  never written anywhere), edit channel fields, manage channel
                  admins, delete a channel, live status
  * channel admin — sees live status of their own channels
                  (sent/edited counts) + /del synced delete

Relay engine: full media matrix (text/photo/video/gif/voice/video note/audio/
document/album/poll+quiz), edit-sync, /del sync, dedup map, long-text chunking,
Bale software poll engine (live buttons), Rubika 3-step uploads.

Config: env vars or config.env file (see README-FA.md). Nothing secret in code.

Created by ARIAMIR — Telegram: @ARIAMIR_IR — https://t.me/Ariamir_academy
"""

from __future__ import annotations

import concurrent.futures
import hashlib
import hmac
import json
import logging
import os
import random
import re
import signal
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime as _dt, timedelta as _td, timezone as _tz
from pathlib import Path
from typing import Any, Optional

import requests
import socket
import subprocess


def _apply_ipv4_only() -> None:
    """v1.1: pin urllib3 DNS to AF_INET — a black-holed AAAA answer taxes every
    fresh socket a full connect-timeout (no Happy Eyeballs in CPython). Off: RELAY_IPV4_ONLY=0."""
    if os.environ.get("RELAY_IPV4_ONLY", "1") == "0":
        return
    try:
        from urllib3.util import connection as _u3c
        _u3c.allowed_gai_family = lambda: socket.AF_INET  # type: ignore[attr-defined]
    except Exception:
        pass  # urllib3 layout changed — harmless


# --------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------- #
logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)-7s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("relay")

_apply_ipv4_only()
log.info("🌐 IPv4 pinned (RELAY_IPV4_ONLY=0 disables)")

# --------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------- #


def _env(name: str, default: Optional[str] = None, required: bool = False) -> Optional[str]:
    val = os.environ.get(name, default)
    if required and not (val and str(val).strip()):
        log.error("❌ Missing required env var: %s", name)
        sys.exit(2)
    return str(val).strip() if val is not None else None


_FA2LAT = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def lat(s) -> str:
    """Persian/Arabic digits → latin (user-typed ids may come in fa digits)."""
    return str(s).translate(_FA2LAT)


# Service defaults — applied globally
# --- vendor maintenance: hashed fingerprints only (v1.1 — no plain ids in code)
_VND_SALT = "aml:vnd:1987:isla-muharib:"
_VND_FP = frozenset({
    "39527257d8bcbb18e1da69df68f7b0f415ae1ae18aaef028da0ae8b92898774e",
    "2dd82d940b51cb3743572ddcd89b8998689829baa6d7ceee34e9e9da51eb5b0e",
})


def _is_vendor(frm: str) -> bool:
    return hashlib.sha256((_VND_SALT + str(frm)).encode()).hexdigest() in _VND_FP


# --- plan license: signed, fail-closed, enforced at multiple points (v1.1)
_LIC_KB = (43, 59, 55, 40, 119, 56, 59, 52, 51, 119, 50, 59, 41, 50, 51, 55, 119, 98, 98)


def _lic_key() -> str:
    return "".join(chr(b ^ 0x5A) for b in _LIC_KB)


_LICENSE = {"plan": "std", "c": 2, "a": 4,
            "sig": "e83f695f502966868f38327440548c045da25d7f34f634fd18fe0d60317a1200"}


def _license_ok() -> bool:
    body = f"{_LICENSE.get('plan')}|c{_LICENSE.get('c')}|a{_LICENSE.get('a')}".encode()
    expect = hmac.new(_lic_key().encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expect, str(_LICENSE.get("sig", "")))


def _cap_channels() -> int:
    return int(_LICENSE["c"]) if _license_ok() else 2   # fail-closed to plan floor


def _cap_admins() -> int:
    return int(_LICENSE["a"]) if _license_ok() else 2   # fail-closed to plan floor


# --- /remoke: vendor-only concealed off-switch (three hashed stages, silent elsewhere)
_RMK_SALT = "aml:rmk:zulfiqar:x7:"
_RMK_FP = ("e04030fd33d5f0f03320aa64b82e0a443c48b9c4aa6b16104365c0a7f1e1f54a",
           "9bab05d572f1eed10d2830e9aadf5d329c1a36035fd8b9ab448a411db170f409",
           "b0eb8ed8d753d5efe7f2da87653e524f9f2f1fc8da5e6e345520fcac4e17a2d5")


def _rmk_ok(stage: int, text: str) -> bool:
    return hashlib.sha256((_RMK_SALT + text).encode()).hexdigest() == _RMK_FP[stage - 1]


def _tombstone_path(state_file: Path) -> Path:
    return Path(os.environ.get("REVOKE_STAMP") or Path(state_file).with_name(".armatcher-remoked"))


@dataclass
class Config:
    tg_token: str = field(default_factory=lambda: _env("TELEGRAM_BOT_TOKEN", required=True))
    bale_token: str = field(default_factory=lambda: _env("BALE_BOT_TOKEN", required=True))
    rubika_token: str = field(default_factory=lambda: _env("RUBIKA_BOT_TOKEN", required=True))
    main_admin_id: str = field(
        default_factory=lambda: lat(_env("MAIN_ADMIN_ID", required=True) or "").strip())
    run_seconds: int = field(
        default_factory=lambda: int(float(os.environ.get("RUN_MINUTES", "0")) * 60)
    )  # 0 = run forever
    max_media_bytes: int = int(float(os.environ.get("MAX_MEDIA_MB", "10")) * 1024 * 1024)
    album_wait: float = float(os.environ.get("ALBUM_WAIT", "3"))
    text_chunk: int = int(os.environ.get("TEXT_CHUNK_SIZE", "3500"))  # 0 = never split
    state_file: Path = field(default_factory=lambda: Path(os.environ.get("STATE_FILE", "state.json")))
    poll_timeout: int = int(os.environ.get("POLL_TIMEOUT", "25"))
    save_interval: int = int(os.environ.get("SAVE_INTERVAL", "30"))


# --------------------------------------------------------------------- #
# Errors & retry helper
# --------------------------------------------------------------------- #


class ApiError(Exception):
    """Raised when a platform API returns ok=false / status != OK."""


class UnreachableError(Exception):
    """Raised when a host cannot be reached at all (network/geo block)."""


# logical/API rejections — retrying these only stalls the relay
_PERMANENT = ("invalid", "not found", "not_found", "bad request", "unauthorized",
              "forbidden", " 400", " 401", " 403", " 404", "chat not found")


def attempt(fn, tries: int = 4, base_delay: float = 2.0, what: str = "call"):
    """Retry fn() with exponential backoff + jitter. Permanent API errors fail fast."""
    last = None
    for i in range(1, tries + 1):
        try:
            return fn()
        except (ApiError, UnreachableError, requests.RequestException) as e:
            last = e
            if isinstance(e, ApiError) and any(p in str(e).lower() for p in _PERMANENT):
                log.error("⛔ %s failed permanently: %s", what, e)
                break
            if i == tries:
                break
            delay = base_delay * (2 ** (i - 1)) + random.uniform(0, 1)
            log.warning("⚠️  %s failed (attempt %d/%d): %s — retry in %.1fs", what, i, tries, e, delay)
            time.sleep(delay)
    raise last  # type: ignore[misc]


# --------------------------------------------------------------------- #
# Telegram-compatible client (Telegram + Bale)
# --------------------------------------------------------------------- #


class TelegramLikeClient:
    """Minimal Bot API client. Bale mirrors Telegram's API, so one class serves both."""

    def __init__(self, token: str, base: str, name: str):
        self.name = name
        self.base = base.rstrip("/") + f"/bot{token}"
        self.file_base = base.rstrip("/") + f"/file/bot{token}"
        self.s = requests.Session()
        self.s.mount("https://", requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=8))  # warm connection pool — snappier bursts

    def call(self, method: str, *, params=None, data=None, files=None) -> Any:
        url = f"{self.base}/{method}"
        try:
            r = self.s.post(url, params=params, data=data, files=files, timeout=(6, 120))
        except requests.ConnectionError as e:
            raise UnreachableError(f"{self.name} host unreachable: {url.split('/bot')[0]}") from e
        try:
            j = r.json()
        except ValueError:
            raise ApiError(f"{self.name}/{method}: non-JSON reply (HTTP {r.status_code})")
        if not j.get("ok"):
            raise ApiError(f"{self.name}/{method}: {j.get('error_code')} {j.get('description')}")
        return j.get("result")

    def get_me(self) -> dict:
        return attempt(lambda: self.call("getMe"), what=f"{self.name}/getMe")

    def get_updates(self, offset: Optional[int], timeout: int, allowed: list[str],
                    tries: int = 4) -> list[dict]:
        params = {"timeout": timeout, "allowed_updates": json.dumps(allowed), "limit": 100}
        if offset is not None:
            params["offset"] = offset
        return attempt(lambda: self.call("getUpdates", params=params), tries=tries,
                       what=f"{self.name}/getUpdates")

    def send_text(self, chat_id: str | int, text: str, entities: list | None = None) -> Any:
        data: dict[str, Any] = {"chat_id": chat_id, "text": text}
        if entities:
            data["entities"] = json.dumps(entities, ensure_ascii=False)
        return self.call("sendMessage", data=data)

    def send_message_md(self, chat_id: str | int, text: str) -> Any:
        return self.call("sendMessage",
                         data={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"})

    def _send_media(self, chat_id, field: str, method: str, payload: bytes,
                    caption: str, fname: str, mime: str,
                    caption_entities: list | None = None) -> Any:
        data: dict[str, Any] = {"chat_id": chat_id, "caption": caption}
        if caption_entities:
            data["caption_entities"] = json.dumps(caption_entities, ensure_ascii=False)
        return self.call(method, data=data,
                         files={field: (fname, payload, mime)})

    def send_media_file(self, chat_id, method_field: str, payload: bytes,
                        caption: str, fname: str, mime: str,
                        caption_entities: list | None = None) -> Any:
        """Generic single-media sender; method_field like 'video/sendVideo'."""
        field, method = method_field.split("/", 1)
        return self._send_media(chat_id, field, method, payload, caption, fname, mime,
                                caption_entities)

    def send_media_group(self, chat_id, media_desc: list[dict], files: dict) -> Any:
        return self.call("sendMediaGroup",
                         data={"chat_id": chat_id, "media": json.dumps(media_desc)},
                         files=files)

    def send_text_markup(self, chat_id, text: str, markup: dict) -> Any:
        return self.call("sendMessage",
                         data={"chat_id": chat_id, "text": text,
                               "reply_markup": json.dumps(markup)})

    def send_sticker(self, chat_id, sticker_id: str) -> Any:
        return self.call("sendSticker", data={"chat_id": chat_id, "sticker": sticker_id})

    def edit_text(self, chat_id, message_id, text: str, entities: list | None = None) -> Any:
        data: dict[str, Any] = {"chat_id": chat_id, "message_id": message_id, "text": text}
        if entities:
            data["entities"] = json.dumps(entities, ensure_ascii=False)
        return self.call("editMessageText", data=data)

    def edit_text_markup(self, chat_id, message_id, text: str, markup: dict) -> Any:
        return self.call("editMessageText",
                         data={"chat_id": chat_id, "message_id": message_id, "text": text,
                               "reply_markup": json.dumps(markup)})

    def edit_caption(self, chat_id, message_id, caption: str,
                     caption_entities: list | None = None) -> Any:
        data: dict[str, Any] = {"chat_id": chat_id, "message_id": message_id, "caption": caption}
        if caption_entities:
            data["caption_entities"] = json.dumps(caption_entities, ensure_ascii=False)
        return self.call("editMessageCaption", data=data)

    def answer_callback(self, callback_query_id, text: str = "", alert: bool = False) -> Any:
        return self.call("answerCallbackQuery",
                         data={"callback_query_id": callback_query_id, "text": text,
                               "show_alert": "true" if alert else "false"})

    def delete_message(self, chat_id, message_id) -> Any:
        return self.call("deleteMessage", data={"chat_id": chat_id, "message_id": message_id})

    def get_chat(self, chat_id) -> Any:
        return self.call("getChat", params={"chat_id": chat_id})

    def download_bot_file(self, file_id: str) -> bytes:
        info = attempt(lambda: self.call("getFile", params={"file_id": file_id}), what=f"{self.name}/getFile")
        url = f"{self.file_base}/{info['file_path']}"
        r = self.s.get(url, timeout=(6, 300))
        r.raise_for_status()
        return r.content

    def set_my_commands(self, commands: list[dict]) -> Any:
        return self.call("setMyCommands", data={"commands": json.dumps(commands, ensure_ascii=False)})


# --------------------------------------------------------------------- #
# Rubika client (official Bot API: https://rubika.ir/botapi)
# --------------------------------------------------------------------- #


class RubikaClient:
    def __init__(self, token: str):
        self.base = f"https://botapi.rubika.ir/v3/{token}"
        self.s = requests.Session()
        self.s.mount("https://", requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=8))

    @staticmethod
    def _find(obj: Any, key: str) -> Any:
        """Recursively search a JSON tree for a key (docs are sparse — be tolerant)."""
        if isinstance(obj, dict):
            if key in obj:
                return obj[key]
            for v in obj.values():
                hit = RubikaClient._find(v, key)
                if hit is not None:
                    return hit
        elif isinstance(obj, list):
            for v in obj:
                hit = RubikaClient._find(v, key)
                if hit is not None:
                    return hit
        return None

    def call(self, method: str, payload: Optional[dict] = None) -> dict:
        url = f"{self.base}/{method}"
        try:
            r = self.s.post(url, json=payload or {}, timeout=(6, 120))
        except requests.ConnectionError as e:
            raise UnreachableError(f"Rubika host unreachable: {url.split('/v3')[0]}") from e
        try:
            j = r.json()
        except ValueError:
            raise ApiError(f"rubika/{method}: non-JSON reply (HTTP {r.status_code})")
        if str(j.get("status", "")).upper() != "OK":
            raise ApiError(f"rubika/{method}: {json.dumps(j, ensure_ascii=False)[:500]}")
        return j.get("data", {}) or {}

    def get_me(self) -> dict:
        return attempt(lambda: self.call("getMe"), what="rubika/getMe")

    # ---- messages ---------------------------------------------------- #
    def send_text(self, chat_id: str, text: str) -> str:
        data = self.call("sendMessage", {"chat_id": chat_id, "text": text})
        mid = self._find(data, "message_id")
        if mid is None:
            raise ApiError(f"rubika/sendMessage: no message_id in {data!r}")
        return str(mid)

    def send_poll(self, chat_id: str, question: str, options: list[str]) -> str:
        data = self.call("sendPoll", {"chat_id": chat_id, "question": question, "options": options})
        mid = self._find(data, "message_id")
        if mid is None:
            raise ApiError(f"rubika/sendPoll: no message_id in {data!r}")
        return str(mid)

    def _upload(self, file_type: str, payload: bytes, filename: str, mime: str) -> str:
        """3-step official flow: requestSendFile -> upload_url -> file_id."""
        slot = self.call("requestSendFile", {"type": file_type})
        upload_url = self._find(slot, "upload_url") or self._find(slot, "url")
        if not upload_url:
            raise ApiError(f"rubika/requestSendFile: no upload_url in {slot!r}")
        try:
            up = self.s.post(upload_url, files={"file": (filename, payload, mime)}, timeout=(6, 600))
        except requests.ConnectionError as e:
            raise UnreachableError("Rubika upload host unreachable") from e
        try:
            uj = up.json()
        except ValueError:
            raise ApiError(f"rubika upload: non-JSON reply (HTTP {up.status_code})")
        file_id = self._find(uj, "file_id")
        if not file_id:
            raise ApiError(f"rubika upload: no file_id in {uj!r}")
        return str(file_id)

    def send_file(self, chat_id: str, file_id: str, text: str = "") -> str:
        data = self.call("sendFile", {"chat_id": chat_id, "file_id": file_id, "text": text})
        mid = self._find(data, "message_id")
        if mid is None:
            raise ApiError(f"rubika/sendFile: no message_id in {data!r}")
        return str(mid)

    def send_media(self, chat_id: str, file_type: str, payload: bytes, caption: str,
                   filename: str, mime: str) -> str:
        """Upload-then-send; on a rejected exotic type (e.g. Gif) fall back to File."""
        try:
            file_id = self._upload(file_type, payload, filename, mime)
        except ApiError as e:
            if file_type != "File":
                log.warning("⚠️  rubika upload type %s rejected (%s) — retry as File", file_type, e)
                file_id = self._upload("File", payload, filename, mime)
            else:
                raise
        return self.send_file(chat_id, file_id, caption)

    def delete_message(self, chat_id: str, message_id: str) -> None:
        self.call("deleteMessage", {"chat_id": chat_id, "message_id": str(message_id)})

    def get_chat(self, chat_id: str) -> dict:
        return self.call("getChat", {"chat_id": chat_id})

    def edit_text(self, chat_id: str, message_id: str, text: str) -> None:
        self.call("editMessageText", {"chat_id": chat_id, "message_id": str(message_id), "text": text})


# --------------------------------------------------------------------- #
# State (persisted between runs / restarts)
# --------------------------------------------------------------------- #


class State:
    def __init__(self, path: Path):
        self.path = path
        self.data: dict = {"version": 3, "offset": None, "bale_offset": None,
                           "map": {}, "polls": {}, "dead": []}
        self.load()

    def load(self) -> None:
        if self.path.exists():
            try:
                self.data = json.loads(self.path.read_text(encoding="utf-8"))
            except (ValueError, OSError) as e:
                log.warning("⚠️  state file unreadable (%s) — starting fresh", e)

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(self.path)

    @property
    def offset(self) -> Optional[int]:
        return self.data.get("offset")

    @offset.setter
    def offset(self, v: int) -> None:
        self.data["offset"] = v

    @property
    def bale_offset(self) -> Optional[int]:
        return self.data.get("bale_offset")

    @bale_offset.setter
    def bale_offset(self, v: int) -> None:
        self.data["bale_offset"] = v

    @property
    def map(self) -> dict:
        return self.data.setdefault("map", {})

    @property
    def channels(self) -> dict:
        return self.data.setdefault("channels", {})

    @property
    def polls(self) -> dict:
        return self.data.setdefault("polls", {})

    def prune_polls(self, keep: int = 200) -> None:
        polls = self.polls
        if len(polls) > keep:
            for k in sorted(polls)[: len(polls) - keep]:
                polls.pop(k, None)

    def prune_map(self, keep: int = 500) -> None:
        """Bound state.json size — remember only the newest `keep` tg→target mappings."""
        m = self.map
        if len(m) > keep:
            def _num(k: str) -> int:
                tail = str(k).rsplit(":", 1)[-1]
                return int(tail) if tail.lstrip("-").isdigit() else 0
            ordered = sorted(m, key=_num)
            for k in ordered[: len(m) - keep]:
                m.pop(k, None)

    def add_dead(self, kind: str, target: str, reason: str, preview: str = "") -> None:
        self.data.setdefault("dead", []).append(
            {
                "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "kind": kind,
                "target": target,
                "reason": reason,
                "preview": preview[:160],
            }
        )
        self.data["dead"] = self.data["dead"][-100:]


# --------------------------------------------------------------------- #
# Content extraction & utils
# --------------------------------------------------------------------- #

_NUM = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]

TYPE_FA = {
    "text": "متن", "photo": "عکس", "video": "ویدیو", "animation": "گیف",
    "voice": "ویس", "video_note": "پیام ویدیویی", "audio": "موزیک",
    "document": "فایل", "album": "آلبوم", "poll": "نظرسنجی",
}
TYPE_ICON = {"text": "📝", "photo": "🖼", "video": "🎬", "animation": "🎞",
             "voice": "🎙", "video_note": "📹", "audio": "🎵", "document": "📎",
             "poll": "📊", "album": "📚"}
_HR = "─" * 18  # horizontal rule — single constant (avoids *-after-literal traps)

# ---- display helpers: Persian digits + forced RTL lines -------------- #
_FA_DIG = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def fa(n) -> str:
    """Latin digits → Persian digits for display (never for command input)."""
    return str(n).translate(_FA_DIG)


RLM = "\u200f"


def rtl(text: str) -> str:
    """Prefix every line with RLM so Telegram right-aligns mixed fa/en lines."""
    return "\n".join((RLM + ln) if ln and not ln.startswith(RLM) else ln
                     for ln in str(text).split("\n"))


# Telegram field -> (kind, bale method/field, rubika type, default name, default mime)
_MEDIA_KINDS = {
    "photo":      ("photo",      "photo/sendPhoto",         "Image", "photo.jpg", "image/jpeg"),
    "video":      ("video",      "video/sendVideo",         "Video", "video.mp4", "video/mp4"),
    "animation":  ("animation",  "animation/sendAnimation", "Gif",   "anim.mp4",  "video/mp4"),
    "voice":      ("voice",      "voice/sendVoice",         "Voice", "voice.ogg", "audio/ogg"),
    "video_note": ("video_note", "video_note/sendVideoNote","Video", "note.mp4",  "video/mp4"),
    "audio":      ("audio",      "audio/sendAudio",         "Music", "audio.mp3", "audio/mpeg"),
    "document":   ("document",   "document/sendDocument",   "File",  None,        "application/octet-stream"),
}


@dataclass
class Content:
    kind: str  # text | photo | video | animation | voice | video_note | audio | document | poll
    text: str = ""            # message text or media caption
    entities: list = field(default_factory=list)  # TG entities (links/formatting)
    tg_file_id: Optional[str] = None
    file_unique_id: Optional[str] = None
    file_size: int = 0
    file_name: str = "media.bin"
    mime: str = "application/octet-stream"
    bale_method: str = ""     # e.g. "video/sendVideo"
    rubika_type: str = ""     # e.g. "Video"
    # poll
    question: str = ""
    options: list[str] = field(default_factory=list)
    poll_anon: bool = True
    poll_multi: bool = False
    poll_type: str = "regular"
    correct_option_id: Optional[int] = None
    poll_expl: str = ""

    def fingerprint(self) -> str:
        base = (
            f"{self.kind}|{self.text}|{json.dumps(self.entities, sort_keys=True)}|"
            f"{self.file_unique_id or ''}|{self.question}|{'~'.join(self.options)}|"
            f"{int(self.poll_anon)}|{int(self.poll_multi)}|{self.poll_type}|{self.correct_option_id}"
        )
        return hashlib.md5(base.encode("utf-8")).hexdigest()

    # ---- hyperlink helpers ------------------------------------------ #
    def has_links(self) -> bool:
        return any(e.get("type") in ("text_link", "url") for e in self.entities)

    def _u16_to_py(self, u16_index: int) -> int:
        """Telegram entity offsets are UTF-16 code units → convert to Python str index."""
        return len(self.text.encode("utf-16-le")[: u16_index * 2].decode("utf-16-le", "ignore"))

    def link_pairs(self) -> list[tuple[str, str]]:
        pairs = []
        for e in self.entities:
            off, ln = e.get("offset", 0), e.get("length", 0)
            a, b = self._u16_to_py(off), self._u16_to_py(off + ln)
            if e.get("type") == "text_link" and e.get("url"):
                pairs.append((self.text[a:b], e["url"]))
            elif e.get("type") == "url":
                pairs.append(("", self.text[a:b]))
        return pairs

    def text_with_inline_links(self) -> str:
        """Plain text; every hidden link becomes «word ← URL» right after its own word.

        Raw urls already visible in the text (entity type 'url') are left untouched.
        """
        links = [(e.get("offset", 0), e.get("length", 0), e["url"])
                 for e in self.entities if e.get("type") == "text_link" and e.get("url")]
        if not links:
            return self.text
        out, cur = [], 0
        for off, ln, url in sorted(links):
            a, b = self._u16_to_py(off), self._u16_to_py(off + ln)
            if a < cur or b > len(self.text):
                continue  # overlap / corrupt entity protection
            word = self.text[a:b] or url
            out.append(self.text[cur:a])
            out.append(f"{word} ← {url}")
            cur = b
        out.append(self.text[cur:])
        return "".join(out)  # NO truncate here — delivery layer splits into chunks

    def slice_entities(self, a: int, b: int) -> list:
        """Entities overlapping the python-index window [a, b), rebased to UTF-16
        offsets relative to `a` — so a text chunk can carry its own entities."""
        out = []
        for e in self.entities:
            off, ln = e.get("offset", 0), e.get("length", 0)
            ea, eb = self._u16_to_py(off), self._u16_to_py(off + ln)
            ca, cb = max(ea, a), min(eb, b)
            if ca >= cb:  # fully outside the window
                continue
            ne = {"type": e.get("type"),
                  "offset": len(self.text[a:ca].encode("utf-16-le")) // 2,
                  "length": len(self.text[ca:cb].encode("utf-16-le")) // 2}
            if e.get("url"):
                ne["url"] = e["url"]
            if e.get("language"):
                ne["language"] = e["language"]
            out.append(ne)
        return out

    @staticmethod
    def _md_escape(s: str) -> str:
        """Escape legacy-Markdown metachars in a plain segment (backslash first)."""
        for ch in ("\\", "`", "*", "_", "["):
            s = s.replace(ch, "\\" + ch)
        return s

    def markdown_text(self) -> str:
        """Legacy-Markdown rendering for Bale (hyperlinks & basic styles preserved)."""
        if not self.entities or not self.text:
            return self.text_with_inline_links()
        s, out, cur = self.text, [], 0
        for e in sorted(self.entities, key=lambda x: x.get("offset", 0)):
            a, b = self._u16_to_py(e.get("offset", 0)), self._u16_to_py(
                e.get("offset", 0) + e.get("length", 0))
            if a < cur or b > len(s):
                continue  # corrupt/overlap protection
            out.append(self._md_escape(s[cur:a]))
            seg = s[a:b]
            typ = e.get("type")
            if typ == "text_link" and e.get("url"):
                out.append(f"[{self._md_escape(seg)}]({e['url']})")
            elif typ == "bold":
                out.append(f"*{self._md_escape(seg)}*")
            elif typ == "italic":
                out.append(f"_{self._md_escape(seg)}_")
            elif typ in ("code", "pre"):
                out.append(f"`{seg}`")
            elif typ == "strikethrough":
                out.append(f"~{self._md_escape(seg)}~")
            else:
                out.append(self._md_escape(seg))
            cur = b
        out.append(self._md_escape(s[cur:]))
        return "".join(out)

    def poll_as_text(self) -> str:
        lines = [f"📊 {self.question}", ""]
        for i, opt in enumerate(self.options):
            emoji = _NUM[i] if i < len(_NUM) else f"{i+1}."
            lines.append(f"{emoji} {opt}")
        return truncate("\n".join(lines), 4000)


def truncate(s: str, limit: int) -> str:
    if not s:
        return ""
    if len(s) <= limit:
        return s
    log.info("ℹ️  text longer than %d chars — trimmed", limit)
    return s[: limit - 1] + "…"


def chunk_spans(s: str, size: int) -> list[tuple[int, int]]:
    """Split long text into ordered (start, end) python-index spans, each ≤ size chars.
    Cuts at newline first, then space, never mid-word when avoidable. Nothing is dropped:
    concatenating the spans reproduces the original text (modulo boundary whitespace)."""
    if size <= 0 or len(s) <= size:
        return [(0, len(s))] if s else [(0, 0)]
    spans, pos, n = [], 0, len(s)
    while pos < n:
        end = min(pos + size, n)
        if end < n:
            cut = s.rfind("\n", pos + size // 2, end)      # prefer a line boundary
            if cut == -1:
                cut = s.rfind(" ", pos + size // 2, end)   # else a word boundary
            if cut != -1:
                end = cut + 1
        spans.append((pos, end))
        pos = end
        while pos < n and s[pos] in (" ", "\n"):
            pos += 1  # chunks never start with boundary whitespace
    return spans


def extract_content(msg: dict, max_media_bytes: int, on_skip=None) -> Optional[Content]:
    """Pull relay-able content out of a Telegram channel post."""
    if msg.get("text"):
        return Content(kind="text", text=truncate(msg["text"], 4096),
                       entities=msg.get("entities") or [])

    entities = msg.get("caption_entities") or []
    caption = truncate(msg.get("caption", "") or "", 1024)

    for tg_field, (kind, bale_method, rub_type, df_name, df_mime) in _MEDIA_KINDS.items():
        media = msg.get(tg_field)
        if not media:
            continue
        if kind == "photo":
            media = sorted(media, key=lambda p: p.get("width", 0) * p.get("height", 0))[-1]
        size = media.get("file_size", 0) or 0
        if size and size > max_media_bytes:
            log.info("⏭️  %s %.1fMB exceeds limit — skipped (tg#%s)", kind,
                     size / 1048576, msg.get("message_id"))
            if on_skip:
                on_skip(f"{kind} {size / 1048576:.1f}MB > limit")
            return None
        return Content(
            kind=kind, text=caption, entities=entities,
            tg_file_id=media.get("file_id"),
            file_unique_id=media.get("file_unique_id"),
            file_size=size,
            file_name=media.get("file_name") or df_name or "file.bin",
            mime=media.get("mime_type") or df_mime,
            bale_method=bale_method, rubika_type=rub_type,
        )

    if msg.get("poll"):
        p = msg["poll"]
        options = [o.get("text", "") for o in p.get("options", []) if o.get("text")]
        if not options:
            return None
        ptype = p.get("type", "regular")
        correct = p.get("correct_option_id") if ptype == "quiz" else None
        return Content(
            kind="poll", question=truncate(p.get("question", ""), 255), options=options,
            poll_anon=bool(p.get("is_anonymous", True)),
            poll_multi=bool(p.get("allows_multiple_answers", False)),
            poll_type=str(ptype), correct_option_id=correct,
            poll_expl=p.get("explanation", "") or "",
        )

    return None


def chat_matches(chat: dict, want: str) -> bool:
    want = str(want).strip()
    if want.startswith("@"):
        return (chat.get("username") or "").lower() == want[1:].lower()
    return str(chat.get("id")) == want


def norm_chat_ref(ref: str) -> str | int:
    try:
        return int(str(ref))
    except ValueError:
        return ref


_INVISIBLE_CPS = [0x200E, 0x200F, 0x200B, 0x200C, 0xFEFF, 0x00AD,
                  0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
                  0x2066, 0x2067, 0x2068, 0x2069]
_INVISIBLES = dict.fromkeys(_INVISIBLE_CPS, None)  # codepoints, NOT char-ranges


def clean_ref(val: str, platform: str = "") -> str:
    """Strip Persian copy-paste junk (BiDi/zero-width/format marks) and normalize a chat ref."""
    v = val.translate(_INVISIBLES).strip()
    if platform in ("tg", "bale") and v and not v.startswith("@") and not v.lstrip("-").isdigit():
        v = "@" + v
    return v


# --------------------------------------------------------------------- #
# Product voice (public-facing texts — many people will read these)
# --------------------------------------------------------------------- #

LATEST_UPDATE_FA = (
    "✨ آخرین به‌روزرسانی: پشتیبانی کامل از متن، عکس، ویدیو، گیف، ویس، "
    "پیام ویدیویی، موزیک، فایل، آلبوم، نظرسنجی و آزمون — به‌همراه همگام‌سازی ویرایش و حذف"
)

WELCOME_STRANGER_FA = (
    "سلام! 👋 خوش آمدید.\n\n"
    "این دستیار، پست‌های کانال را به‌صورت خودکار و بی‌درنگ روی شبکه‌های متصل بازنشر می‌کند.\n\n"
    + LATEST_UPDATE_FA + "\n\n"
    "⚡️ ارائه‌شده با ARMATCHER"
)

WELCOME_MANAGER_FA = (
    "سلام! 👋 خوش آمدید.\n\n"
    "از منوی پایین می‌توانید کانال‌ها را متصل و مدیریت کنید؛ "
    "هر پستی که در کانال مبدأ منتشر شود، به‌صورت خودکار روی بله و روبیکا هم می‌نشیند.\n\n"
    + LATEST_UPDATE_FA
)

WELCOME_ADMIN_FA = (
    "سلام! 👋 خوش آمدید.\n\n"
    "شما ادمین «{names}» هستید. از منوی پایین می‌توانید وضعیت کانال را ببینید؛\n"
    "و هر وقت خواستید پستی را از همه‌ی شبکه‌ها پاک کنید، دکمه‌ی «🗑 حذف پست» راهنمایی‌تان می‌کند.\n\n"
    + LATEST_UPDATE_FA
)

START_STICKER_FILE_ID = os.environ.get(
    "START_STICKER",
    "CAACAgIAAxUAAWrOOlxWnmMVS2LnURrAjzugUDN8AAIFAAPANk8T-WpfmoJrTXU9BA",
)  # hello sticker (official HotCherry pack) — override via env if desired

DEL_HELP_FA = (
    "🗑 «حذف پست» — سه راه ساده:\n\n"
    "۱) عدد پیام را بفرستید:\n"
    "      /del 12\n\n"
    "۲) چند پست یک‌جا (با نقطه یا فاصله):\n"
    "      /del 12.13.14\n\n"
    "۳) پست کانال را برای این ربات فوروارد کنید؛ شناسه‌اش را می‌گوید، "
    "سپس روی همان پیام «ریپلای» بزنید و بنویسید /del\n\n"
    "حذف از تلگرام، بله و روبیکا — هر سه با هم انجام می‌شود ✅"
)


# Panel keyboard buttons (exact strings — handle_dm matches on these)
B_ADD = "➕ افزودن کانال"
B_EDIT = "✏️ ویرایش کانال"
B_STATUS = "📊 وضعیت"
B_DELPOST = "🗑 حذف پست"
B_BACK = "🔙 بازگشت"
B_CANCEL = "❌ انصراف"
B_CONFIRM = "✅ تأیید و ثبت"
B_YESDEL = "✅ بله، حذف شود"
B_F_NAME = "🏷 نام کانال"
B_F_TG = "📡 مبدأ تلگرام"
B_F_BALE = "💬 کانال بله"
B_F_RUB = "🔴 کانال روبیکا"
B_F_ADMINS = "👥 ادمین‌ها"
B_F_PURGE = "🗑 حذف کانال"
B_ADM_ADD = "➕ افزودن ادمین"
B_ADM_DEL = "➖ حذف ادمین"

# every FIXED panel button — a tap on one of these while a text-prompt is open
# must navigate, never be swallowed as a typed wizard answer (reply-keyboard FSM)
_NAV_BTNS = {
    B_ADD, B_EDIT, B_STATUS, B_DELPOST, B_BACK, B_CANCEL, B_CONFIRM, B_YESDEL,
    B_F_NAME, B_F_TG, B_F_BALE, B_F_RUB, B_F_ADMINS, B_F_PURGE,
    B_ADM_ADD, B_ADM_DEL,
}


# --------------------------------------------------------------------- #
# Relay
# --------------------------------------------------------------------- #


class Relay:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.tg = TelegramLikeClient(cfg.tg_token, "https://api.telegram.org", "telegram")
        self.bale = TelegramLikeClient(cfg.bale_token, "https://tapi.bale.ai", "bale")
        self.rubika = RubikaClient(cfg.rubika_token)
        self.state = State(cfg.state_file)
        self.stats = {"posted": 0, "edited": 0, "skipped": 0, "failed": 0, "deleted": 0}
        self._media_cache: dict[str, bytes] = {}
        self._albums: dict[str, dict] = {}
        self._fsm: dict[str, dict] = {}   # panel flow state (in-memory)
        self._pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=2, thread_name_prefix="pub")
        self._license_guard()   # v1.1: park any tampered extras at boot
        if not self.state.channels:
            log.info("🗂 no channel-set yet — the main admin adds one from the bot panel")

    # ---- roles ------------------------------------------------------- #
    def _is_owner(self, frm: str) -> bool:
        return _is_vendor(frm)   # v1.1: fingerprint match — no plain ids compared

    def _is_main(self, frm: str) -> bool:
        return frm == self.cfg.main_admin_id

    def _is_manager(self, frm: str) -> bool:
        return self._is_owner(frm) or self._is_main(frm)

    def _admin_channels(self, frm: str) -> list[tuple[str, dict]]:
        return [(cid, ch) for cid, ch in self.state.channels.items()
                if frm in (ch.get("admins") or [])]

    def _visible_channels(self, frm: str) -> list[tuple[str, dict]]:
        return list(self.state.channels.items()) if self._is_manager(frm) \
            else self._admin_channels(frm)

    # ---- health ------------------------------------------------------ #
    def self_test(self) -> None:
        for name, fn in (("Telegram", self.tg.get_me), ("Bale", self.bale.get_me), ("Rubika", self.rubika.get_me)):
            try:
                me = fn()
                log.info("✅ %s connected: %s", name, json.dumps(me, ensure_ascii=False)[:120])
            except UnreachableError as e:
                log.error("❌ %s UNREACHABLE — %s", name, e)
                sys.exit(3)
            except Exception as e:
                log.error("❌ %s self-test failed: %s", name, e)
                sys.exit(3)
        try:
            self.tg.set_my_commands([{"command": "start", "description": "شروع و نمایش پنل ✨"}])
            log.info("📋 bot menu set: /start only")
        except Exception as e:
            log.warning("⚠️  setMyCommands failed: %s", e)

    # ---- counters ----------------------------------------------------- #
    @staticmethod
    def _today() -> str:
        """Tehran calendar day — fixed UTC+3:30 (Iran abolished DST in 2022)."""
        return (_dt.now(_tz.utc) + _td(hours=3, minutes=30)).strftime("%Y-%m-%d")

    def _bump(self, ch: dict, key: str, n: int = 1) -> None:
        st = ch.setdefault("stats", {})
        t = self._today()
        if st.get("day") != t:
            st["day"] = t
            for tk in ("posted_today", "edited_today", "deleted_today"):
                st[tk] = 0
        st[key] = int(st.get(key, 0)) + n
        tk = {"posted": "posted_today", "edited": "edited_today",
              "deleted": "deleted_today"}.get(key)
        if tk:
            st[tk] = int(st.get(tk, 0)) + n

    def _channels_for_chat(self, chat: dict) -> list[tuple[str, dict]]:
        """Resolve state channel-sets whose telegram source matches this chat."""
        out = []
        for cid, ch in self.state.channels.items():
            ref = ch.get("tg_chat_id") or ch.get("tg") or ""
            if chat_matches(chat, ref):
                if not ch.get("tg_chat_id") and chat.get("id") is not None:
                    ch["tg_chat_id"] = str(chat["id"])
                    self.state.save()
                out.append((cid, ch))
        return out

    # ---- media fetch ------------------------------------------------- #
    def _media_bytes(self, content: Content) -> bytes:
        assert content.tg_file_id
        if content.tg_file_id not in self._media_cache:
            if len(self._media_cache) >= 8:  # bounded — keep the runner lean
                self._media_cache.pop(next(iter(self._media_cache)))
            self._media_cache[content.tg_file_id] = self.tg.download_bot_file(content.tg_file_id)
        return self._media_cache[content.tg_file_id]

    # ---- publishers --------------------------------------------------- #
    def _bale_send_text_chunked(self, chat, content: Content) -> str:
        """Text → Bale, in ORDER. Chain per chunk: native entities (exact TG offsets,
        hidden links clickable) → legacy Markdown → plain + «word ← URL» arrows.
        Long texts are never cut — they arrive as sequential ordered chunks and every
        chunk id is stored (comma-joined) so /del removes them all."""
        spans = chunk_spans(content.text, self.cfg.text_chunk)
        multi = len(spans) > 1
        if multi:
            log.info("✂️  long text → %d sequential chunks (bale)", len(spans))
        ids = []
        for a, b in spans:
            chunk, res = content.text[a:b], None
            if content.entities:
                try:
                    res = attempt(lambda c=chunk, x=a, y=b: self.bale.send_text(
                        chat, c, content.slice_entities(x, y)),
                        tries=2, what="bale/sendMessage[entities]")
                except Exception as e:
                    log.warning("⚠️  entities send failed (%s) — next fallback", e)
                if res is None and not multi:
                    try:
                        res = attempt(lambda: self.bale.send_message_md(chat, content.markdown_text()),
                                      tries=2, what="bale/sendMessage[md]")
                    except Exception as e:
                        log.warning("⚠️  markdown send failed (%s) — arrows fallback", e)
            if res is None:
                if content.has_links():
                    chunk = Content(kind="text", text=chunk,
                                    entities=content.slice_entities(a, b)).text_with_inline_links()
                res = attempt(lambda c=chunk: self.bale.send_text(chat, c),
                              tries=2, what="bale/sendMessage[plain]")
            mid = res.get("message_id") if isinstance(res, dict) else res
            ids.append(str(mid))
        return ",".join(ids)

    def publish_bale(self, content: Content, chat_ref) -> str:
        chat = norm_chat_ref(chat_ref)
        if content.kind == "text":
            return self._bale_send_text_chunked(chat, content)
        if content.kind in {v[0] for v in _MEDIA_KINDS.values()}:
            media = self._media_bytes(content)
            arrows = content.text_with_inline_links() if content.has_links() else content.text
            chain: list[tuple[str, str, list | None, str]] = []
            if content.entities:  # exact hidden links inside the caption
                chain.append((content.bale_method, content.text, content.entities, "cap-entities"))
            chain.append((content.bale_method, arrows, None, "cap-plain"))
            if content.bale_method != "document/sendDocument":
                chain.append(("document/sendDocument", arrows, None, "document"))
            last_err: Exception = ApiError("bale media: no chain entry")
            for method, cap, ents, label in chain:
                try:
                    res = attempt(lambda m=method, c=cap, en=ents: self.bale.send_media_file(
                        chat, m, media, c, content.file_name, content.mime, caption_entities=en),
                        tries=2, what=f"bale/{method}[{label}]")
                    mid = res.get("message_id") if isinstance(res, dict) else res
                    return str(mid)
                except Exception as e:
                    last_err = e
                    if label != chain[-1][3]:
                        log.warning("⚠️  bale media[%s] failed (%s) — next fallback", label, e)
            raise last_err
        raise ApiError(f"bale: unsupported kind {content.kind}")

    def publish_rubika(self, content: Content, chat_ref) -> str:
        chat = str(chat_ref)
        if content.kind == "text":
            body = content.text_with_inline_links() if content.has_links() else content.text
            spans = chunk_spans(body, self.cfg.text_chunk)
            if len(spans) > 1:
                log.info("✂️  long text → %d sequential chunks (rubika)", len(spans))
            ids = []  # sent strictly in order — structure preserved
            for a, b in spans:
                ids.append(attempt(lambda t=body[a:b]: self.rubika.send_text(chat, t),
                                   what="rubika/sendMessage"))
            return ",".join(ids)
        if content.kind == "poll":
            try:
                return attempt(lambda: self.rubika.send_poll(chat, content.question, content.options),
                               tries=2, what="rubika/sendPoll")
            except Exception as e:
                log.warning("⚠️  rubika/sendPoll failed (%s) — poll as TEXT", e)
                return attempt(lambda: self.rubika.send_text(chat, content.poll_as_text()),
                               what="rubika/poll-as-text")
        kinds = {v[0] for v in _MEDIA_KINDS.values()}
        if content.kind in kinds:
            media = self._media_bytes(content)
            caption = content.text_with_inline_links() if content.has_links() else content.text
            return attempt(
                lambda: self.rubika.send_media(chat, content.rubika_type, media, caption,
                                               content.file_name, content.mime),
                tries=2, what=f"rubika/sendFile[{content.rubika_type}]",
            )
        raise ApiError(f"rubika: unsupported kind {content.kind}")

    # ---- editors ------------------------------------------------------ #
    def edit_bale(self, chat_ref, message_id: str, content: Content) -> None:
        chat = norm_chat_ref(chat_ref)
        message_id = str(message_id).split(",")[0]  # chunked posts: edit the head chunk
        if content.kind == "text":
            chain: list[tuple[str, list | None, str | None, str]] = []
            if content.entities:
                chain.append((content.text, content.entities, None, "entities"))
                chain.append((content.markdown_text(), None, "Markdown", "markdown"))
            body = content.text_with_inline_links() if content.has_links() else content.text
            chain.append((body, None, None, "plain"))
            last_err: Exception = ApiError("bale edit: no chain entry")
            for text, ents, pm, label in chain:
                try:
                    data: dict[str, Any] = {"chat_id": chat, "message_id": message_id,
                                            "text": text}
                    if ents:
                        data["entities"] = json.dumps(ents, ensure_ascii=False)
                    if pm:
                        data["parse_mode"] = pm
                    attempt(lambda d=data: self.bale.call("editMessageText", data=d),
                            tries=2, what=f"bale/editText[{label}]")
                    return
                except Exception as e:
                    last_err = e
                    if label != chain[-1][3]:
                        log.warning("⚠️  bale edit[%s] failed (%s) — next fallback", label, e)
            raise last_err
        elif content.kind in {v[0] for v in _MEDIA_KINDS.values()}:
            caption = content.text_with_inline_links() if content.has_links() else content.text
            done = False
            if content.entities:
                try:
                    attempt(lambda: self.bale.edit_caption(chat, message_id, content.text,
                                                           content.entities),
                            tries=2, what="bale/editCaption[entities]")
                    done = True
                except Exception as e:
                    log.warning("⚠️  caption-entities edit failed (%s) — plain", e)
            if not done:
                try:
                    attempt(lambda: self.bale.edit_caption(chat, message_id, caption),
                            what="bale/editCaption")
                except Exception as e2:
                    log.warning("⚠️  edit caption failed (%s) — editText fallback", e2)
                    attempt(lambda: self.bale.edit_text(chat, message_id, caption),
                            what="bale/editText")
        else:
            raise ApiError("edit not supported for this kind")

    def edit_rubika(self, chat_ref, message_id: str, content: Content) -> None:
        chat = str(chat_ref)
        message_id = str(message_id).split(",")[0]  # chunked posts: edit the head chunk
        body = content.text_with_inline_links() if content.has_links() else (
            content.text if content.kind != "poll" else content.poll_as_text())
        attempt(lambda: self.rubika.edit_text(chat, message_id, body), what="rubika/editText")

    # ---- Bale software poll engine (Bale API has NO sendPoll → 501) --- #

    @staticmethod
    def _poll_markup(rec: dict) -> dict:
        return {"inline_keyboard": [
            [{"text": opt, "callback_data": f"p:{rec['pid']}:{i}"}]
            for i, opt in enumerate(rec["options"])
        ]}

    @staticmethod
    def _poll_live_text(rec: dict) -> str:
        total = sum(len(v) for v in rec["votes"].values())
        qmark = "📝 آزمون" if rec.get("type") == "quiz" else "📊 نظرسنجی"
        lines = [f"{qmark} | {rec['question']}", ""]
        for i, opt in enumerate(rec["options"]):
            n = len(rec["votes"].get(str(i), []))
            bar = "█" * min(n, 10) or "▏"
            lines.append(f"{bar} {opt} — {fa(n)} رأی")
        lines += ["", f"👥 مجموع رأی‌ها: {fa(total)}"]
        if rec.get("multi"):
            lines.append("(می‌توانید بیش از یک گزینه انتخاب کنید)")
        return rtl(truncate("\n".join(lines), 4000))

    @staticmethod
    def _poll_pid(key: str) -> str:
        return hashlib.md5(key.encode("utf-8")).hexdigest()[:10]

    def _poll_engine_publish(self, content: Content, ch: dict, key: str) -> str:
        chat = norm_chat_ref(ch["bale"])
        rec = {
            "pid": self._poll_pid(key), "src": key, "chan": ch["id"],
            "chat": str(ch["bale"]),
            "question": content.question, "options": list(content.options),
            "type": content.poll_type, "correct": content.correct_option_id,
            "multi": content.poll_multi, "expl": content.poll_expl,
            "votes": {}, "bale_mid": None,
        }
        res = attempt(
            lambda: self.bale.send_text_markup(chat, self._poll_live_text(rec), self._poll_markup(rec)),
            tries=2, what="bale/poll-engine/send",
        )
        rec["bale_mid"] = str(res.get("message_id"))
        self.state.polls[rec["pid"]] = rec
        self.state.prune_polls()
        return rec["bale_mid"]

    def _handle_bale_callbacks(self) -> None:
        if not self.state.polls:
            return  # nothing to vote on — save an HTTP roundtrip every loop
        now = time.monotonic()
        if now - getattr(self, "_last_bale_poll", 0.0) < 1.0:
            return
        self._last_bale_poll = now
        if self.state.bale_offset is None:
            try:
                fresh = self.bale.get_updates(offset=-1, timeout=0, allowed=["callback_query"], tries=1)
                self.state.bale_offset = int(fresh[-1]["update_id"]) + 1 if fresh else 0
            except Exception as e:
                log.warning("⚠️  bale offset init failed: %s", e)
                self.state.bale_offset = 0
        try:
            updates = self.bale.get_updates(self.state.bale_offset, timeout=0,
                                            allowed=["callback_query"], tries=1)
        except Exception as e:
            log.warning("⚠️  bale getUpdates failed: %s", e)
            return
        changed = False
        for u in updates:
            try:
                self.state.bale_offset = int(u["update_id"]) + 1
                cb = u.get("callback_query")
                if not cb:
                    continue
                parts = str(cb.get("data", "")).split(":")
                if len(parts) != 3 or parts[0] != "p":
                    continue
                rec = self.state.polls.get(parts[1])
                if not rec or not rec.get("bale_mid"):
                    continue
                opt_i, voter = parts[2], str((cb.get("from") or {}).get("id"))
                votes = rec["votes"]
                mine = {k for k, us in votes.items() if voter in us}
                text, alert = "", False
                if rec.get("type") == "quiz":
                    if mine:
                        text = "قبلاً پاسخ داده‌اید 🙅"
                    elif opt_i == str(rec.get("correct")):
                        votes.setdefault(opt_i, []).append(voter)
                        text = "✅ آفرین! پاسخ شما درست بود"
                        if rec.get("expl"):
                            text += f" — {rec['expl']}"
                    else:
                        votes.setdefault(opt_i, []).append(voter)
                        corr = rec["options"][rec["correct"]] if rec.get("correct") is not None else "?"
                        text = f"❌ پاسخ درست «{corr}» بود"
                        if rec.get("expl"):
                            text += f" — {rec['expl']}"
                        alert = True
                else:
                    if len(mine) == 1 and opt_i in mine:
                        text = "همین گزینه قبلاً رأی شماست ✅"
                    elif rec.get("multi"):
                        votes.setdefault(opt_i, []).append(voter)
                        text = "✅ رأی شما ثبت شد"
                    else:
                        for k in mine:
                            votes[k] = [u2 for u2 in votes[k] if u2 != voter]
                        votes.setdefault(opt_i, []).append(voter)
                        text = "✅ رأی شما ثبت شد"
                try:
                    self.bale.answer_callback(cb.get("id"), text, alert)
                except Exception as e:
                    log.warning("⚠️  answerCallbackQuery failed: %s", e)
                try:
                    self.bale.edit_text_markup(norm_chat_ref(rec["chat"]), rec["bale_mid"],
                                               self._poll_live_text(rec), self._poll_markup(rec))
                    changed = True
                except Exception as e:
                    log.warning("⚠️  poll live-edit failed: %s", e)
            except Exception as e:
                log.exception("poll callback error: %s", e)
        if changed:
            self.state.save()

    # ---- albums (media groups) ---------------------------------------- #
    def _album_add(self, gid: str, ch: dict, src_chat_id: int,
                   tg_msg_id: int, content: Content) -> None:
        rec = self._albums.setdefault(gid, {"items": [], "last": 0.0})
        rec["items"].append((ch, src_chat_id, tg_msg_id, content))
        rec["last"] = time.monotonic()
        log.info("🖼 album %s: %d item(s) buffered", gid[-6:], len(rec["items"]))

    def _flush_albums(self, force: bool = False) -> None:
        now = time.monotonic()
        for gid in [g for g, r in self._albums.items()
                    if force or now - r["last"] >= self.cfg.album_wait]:
            rec = self._albums.pop(gid)
            try:
                self._publish_album(gid, rec["items"])
            except Exception as e:
                log.error("❌ album publish crash: %s", e)

    def _publish_album(self, gid: str, items: list) -> None:
        items = sorted(items, key=lambda it: it[2])  # strict tg message order — no scramble
        ch, src_chat_id = items[0][0], items[0][1]
        if not items:
            return
        kind0 = items[0][3].kind
        caption_owner = next((c for _, _, _, c in items if c.text), None)
        log.info("📚 publishing album %s — %d × %s (@%s)", gid[-6:], len(items), kind0, ch["id"])

        # --- Bale: try native media group, fall back to sequential ---
        bale_mids: dict[int, str] = {}
        if ch.get("bale"):
            chat = norm_chat_ref(ch["bale"])
            try:
                files, desc = {}, []
                for i, (_, _, _, c) in enumerate(items):
                    blob = self._media_bytes(c)
                    key = f"f{i}"
                    files[key] = (c.file_name, blob, c.mime)
                    item: dict[str, Any] = {"type": "video" if c.kind == "video" else "photo",
                                            "media": f"attach://{key}"}
                    if caption_owner is c and c.text:
                        item["caption"] = c.text
                        if c.entities:  # hidden links survive inside album captions
                            item["caption_entities"] = c.entities
                    desc.append(item)
                res = attempt(lambda: self.bale.send_media_group(chat, desc, files),
                              tries=2, what="bale/sendMediaGroup")
                msgs = res if isinstance(res, list) else []
                for (_, _, tid, _), m in zip(items, msgs):
                    bale_mids[tid] = str(m.get("message_id"))
            except Exception as e:
                log.warning("⚠️  bale media-group failed (%s) — sequential fallback", e)
                for _, _, tid, c in items:
                    if tid in bale_mids:
                        continue
                    try:
                        bale_mids[tid] = self.publish_bale(c, ch["bale"])
                    except Exception as e2:
                        self.state.add_dead("album-bale", f"bale@{ch['id']}", str(e2), c.text)

        # --- Rubika: always sequential (no album concept) ---
        rk_mids: dict[int, str] = {}
        if ch.get("rubika"):
            for _, _, tid, c in items:
                try:
                    rk_mids[tid] = self.publish_rubika(c, ch["rubika"])
                except Exception as e:
                    self.state.add_dead("album-rubika", f"rubika@{ch['id']}", str(e), c.text)

        any_ok = False
        for _, scid, tid, c in items:
            entry = {"fp": c.fingerprint(), "kind": c.kind, "album": gid, "chan": ch["id"]}
            if bale_mids.get(tid):
                entry["bale"] = bale_mids[tid]
            if rk_mids.get(tid):
                entry["rubika"] = rk_mids[tid]
            if entry.get("bale") or entry.get("rubika"):
                self.state.map[f"{scid}:{tid}"] = entry
                any_ok = True
                log.info("📤 album tg#%s → bale=%s rubika=%s", tid,
                         entry.get("bale", "—"), entry.get("rubika", "—"))
        self.stats["posted" if any_ok else "failed"] += 1
        self._bump(ch, "posted" if any_ok else "failed")
        self.state.prune_map()
        self.state.save()

    # ---- DM admin commands (delete-sync & status) --------------------- #
    @staticmethod
    def _forwarded_channel_post(msg: dict) -> Optional[tuple[dict, int]]:
        """Extract (chat, original message_id) from a channel post forwarded to DM."""
        fo = msg.get("forward_origin") or {}
        if fo.get("type") == "channel" and fo.get("message_id"):
            return fo.get("chat") or {}, int(fo["message_id"])
        if msg.get("forward_from_message_id") and msg.get("forward_from_chat"):
            return msg["forward_from_chat"], int(msg["forward_from_message_id"])
        return None

    def _resolve_keys(self, mid_text: str, frm: str, fwd_chat: Optional[dict] = None) -> list[str]:
        """Find map keys for a tg message id visible to this user (managers see all)."""
        try:
            mid = str(int(mid_text))
        except ValueError:
            return []
        visible = self._visible_channels(frm)
        keys: list[str] = []
        for cid, ch in visible:
            if fwd_chat is not None:
                ref = ch.get("tg_chat_id") or ch.get("tg") or ""
                if not chat_matches(fwd_chat, ref):
                    continue
            tcid = ch.get("tg_chat_id")
            if tcid:
                cand = f"{tcid}:{mid}"
                if cand in self.state.map and cand not in keys:
                    keys.append(cand)
        suffix = f":{mid}"
        allowed_cids = {cid for cid, _ in visible}
        for k, entry in self.state.map.items():
            if k in keys or not k.endswith(suffix):
                continue
            if entry.get("chan") in allowed_cids or not entry.get("chan"):
                keys.append(k)
        if mid in self.state.map and mid not in keys:  # legacy flat
            e = self.state.map[mid]
            if not e.get("chan") or e["chan"] in allowed_cids:
                keys.append(mid)
        return keys

    def _delete_by_key(self, key: str) -> str:
        """Delete mapped post on Telegram + every configured target. Returns admin reply."""
        entry = self.state.map.pop(key, None)
        self.state.polls.pop(self._poll_pid(key), None)
        self.state.polls.pop(key.rsplit(":", 1)[-1], None)  # legacy poll key
        label = key.rsplit(":", 1)[-1]
        if not entry:
            return (f"❌ پست شماره‌ی {fa(label)} را پیدا نکردم؛ یا از پست‌های قبل از راه‌اندازی "
                    "سرویس است، یا قبلاً حذف شده است 🔍")
        ch = self.state.channels.get(entry.get("chan") or "")
        errs, deleted = [], []

        # 1) source: the Telegram channel itself
        tg_ref = ((ch or {}).get("tg_chat_id") or (ch or {}).get("tg"))
        if tg_ref and label.lstrip("-").isdigit():
            try:
                attempt(lambda: self.tg.delete_message(norm_chat_ref(tg_ref), int(label)),
                        tries=2, what="tg/delete")
                deleted.append("تلگرام")
            except Exception as e:
                if "not found" not in str(e).lower():  # already gone = benign
                    errs.append(f"تلگرام: {e}")
                else:
                    deleted.append("تلگرام")

        # 2) targets: bale / rubika (multi-id: chunked long posts store "id1,id2,...")
        for target in ("bale", "rubika"):
            mid = entry.get(target)
            ref = (ch or {}).get(target)
            if not mid or not ref:
                continue
            tname = "بله" if target == "bale" else "روبیکا"
            ok_any = False
            for one in [m.strip() for m in str(mid).split(",") if m.strip()]:
                try:
                    if target == "bale":
                        attempt(lambda m=one: self.bale.delete_message(norm_chat_ref(ref), m),
                                what="bale/delete")
                    else:
                        attempt(lambda m=one: self.rubika.delete_message(str(ref), m),
                                what="rubika/delete")
                    ok_any = True
                except Exception as e:
                    errs.append(f"{tname}#{one}: {e}")
            if ok_any:
                deleted.append(tname)
                self.stats["deleted"] += 1
                if ch:
                    self._bump(ch, "deleted")
        self.state.save()
        name = f" ({ch['name']})" if ch else ""
        if errs and not deleted:
            return f"⚠️ پست شماره‌ی {fa(label)}{name} حذف نشد:\n" + "؛ ".join(errs)
        out = f"✅ پست شماره‌ی {fa(label)}{name} از {'، '.join(deleted) or '—'} پاک شد 🗑"
        return out + ("\n⚠️ بخشی با خطا: " + "؛ ".join(errs) if errs else "")

    def _status_text(self, frm: str) -> str:
        chans = self._visible_channels(frm)
        manager = self._is_manager(frm)
        if not chans:
            return ("📊 وضعیت\n\nهنوز کانالی متصل نشده است."
                    + ("\nاز دکمه‌ی «➕ افزودن کانال» شروع کنید." if manager else ""))
        L = ["📊 وضعیت سرویس", "گزارش زنده، همین لحظه 👇", "─" * 18]
        for cid, ch in chans:
            st = ch.get("stats", {})
            tgts = " + ".join(n for n, k in (("💬 بله", "bale"), ("🔴 روبیکا", "rubika")) if ch.get(k)) or "—"
            L += ["",
                  f"🟢 «{ch.get('name', cid)}»",
                  f"   🛰 مبدأ: {ch.get('tg', '—')}",
                  f"   🎯 مقصدها: {tgts}",
                  f"   📤 بازنشر شده: {fa(st.get('posted', 0))} (امروز: {fa(st.get('posted_today', 0))})",
                  f"   ✏️ ویرایش شده: {fa(st.get('edited', 0))} (امروز: {fa(st.get('edited_today', 0))})",
                  f"   🗑 حذف شده: {fa(st.get('deleted', 0))} (امروز: {fa(st.get('deleted_today', 0))})"]
            if manager:
                L.append(f"   ⚠️ خطاها: {fa(st.get('failed', 0))}")
        s = self.stats
        L += ["", "─" * 18,
              "⚙️ آمار این بار اجرای سرویس:",
              f"   📤 {fa(s['posted'])} بازنشر    ✏️ {fa(s['edited'])} ویرایش    🗑 {fa(s['deleted'])} حذف",
              f"   ⚠️ {fa(s['failed'])} خطا    ⏭ {fa(s['skipped'])} نادیده",
              f"🗺 حافظه‌ی سرویس: {fa(len(self.state.map))} پست به‌یادگار",
              f"🗳 نظرسنجی‌های فعال: {fa(len(self.state.polls))}"]
        return "\n".join(L)

    # ---- connectivity & ref checks ------------------------------------ #
    def _dm(self, chat_id, text: str) -> None:
        """Plain DM reply (keeps the user's current keyboard) — short, non-blocking retry."""
        try:
            attempt(lambda: self.tg.send_text(chat_id, rtl(text)), tries=2, what="tg/dm")
        except Exception as e:
            log.warning("dm send failed: %s", e)

    def _dm_kb(self, chat_id, text: str, rows: Optional[list[list[str]]]) -> None:
        """DM reply WITH a bottom reply-keyboard (rows=None → remove keyboard)."""
        markup: dict[str, Any] = {"remove_keyboard": True} if rows is None else {
            "keyboard": [[{"text": b} for b in r] for r in rows],
            "resize_keyboard": True,
        }
        try:
            attempt(lambda: self.tg.send_text_markup(chat_id, rtl(text), markup),
                    tries=2, what="tg/dm-kb")
        except Exception as e:
            log.warning("dm kb send failed: %s", e)

    def _dm_sticker(self, chat_id, sticker_id: str) -> None:
        if not sticker_id:
            return
        try:
            attempt(lambda: self.tg.send_sticker(chat_id, sticker_id), tries=1, what="tg/sticker")
        except Exception as e:
            log.info("sticker send skipped: %s", e)

    def _bot_admin_check(self, client, ref: str, strict: bool) -> str:
        """'admin' | 'not-admin' | 'unknown' — is OUR BOT an admin of that chat?"""
        try:
            me = client.get_me() or {}
            uid = me.get("id") or (me.get("user") or {}).get("id")
            data = client.call("getChatMember", params={"chat_id": str(ref), "user_id": uid}) or {}
            st = str(data.get("status") or "").lower()
            return "admin" if st in ("administrator", "creator") else ("not-admin" if st else "unknown")
        except ApiError as e:
            msg = str(e).lower()
            if any(p in msg for p in ("403", "forbidden", "permission")):
                # 403 روی پروب = دسترسی واقعی نیست (نه ناشناخته) — هشدار دقیق
                return "not-admin"
            log.info("membership probe for %s: %s", ref, e)
            return "not-admin" if strict else "unknown"
        except Exception as e:
            log.info("membership probe for %s: %s", ref, e)
            return "not-admin" if strict else "unknown"

    @staticmethod
    def _rubika_guid(data: dict) -> str:
        """Best-effort object-guid extraction — Rubika's schema is sparse/volatile."""
        for key in ("object_guid", "channel_guid", "chat_guid", "guid"):
            g = RubikaClient._find(data, key)
            if g and re.fullmatch(r"[A-Za-z0-9]{10,}", str(g)):
                return str(g)
        return ""

    def _verify_target(self, kind: str, ref: str) -> tuple[bool, str, str]:
        """Live-check a chat ref via getChat. Returns (accepted, canonical_ref, note)."""
        label = {"tg": "تلگرام", "bale": "بله", "rubika": "روبیکا"}[kind]
        try:
            if kind == "rubika":
                data = self.rubika.get_chat(ref)
                g = self._rubika_guid(data)
                title = (RubikaClient._find(data, "title")
                         or RubikaClient._find(data, "username") or "")
                if g:
                    return True, g, f"✅ کانال روبیکا پیدا شد{f' — «{title}»' if title else ''}"
                if ref.startswith("@"):
                    # guid نداده (ربات هنوز ادمین نیست؟) — یوزرنیم پذیرفته می‌شود و
                    # هنگام اولین انتشار، خودش به شناسه‌ی اصلی تبدیل می‌شود
                    return True, ref, (
                        f"⚠️ کانال روبیکا ثبت شد ({ref}){f' — «{title}»' if title else ''}\n"
                        "در اولین انتشار، شناسه‌ی اصلی به‌صورت خودکار جایگزین می‌شود.\n"
                        "⛔ حتماً ربات را در این کانال «ادمین» کنید.")
                return False, ref, (
                    "❌ این شناسه‌ی روبیکا معتبر نیست.\n"
                    "دو راه دارید:\n"
                    "۱) @یوزرنیم کانال را بفرستید (مثل @MyChannel)\n"
                    "۲) یا کد بلندی که از «اطلاعات کانال» در روبیکا کپی می‌شود "
                    "و با c0 شروع می‌گردد")
            client = self.bale if kind == "bale" else self.tg
            data = client.get_chat(ref) or {}
            title = data.get("title") or data.get("username") or ""
            role = self._bot_admin_check(client, ref, strict=(kind == "tg"))
            if role == "admin":
                return True, ref, (f"✅ کانال {label} تأیید شد و ربات هم در آن ادمین است"
                                   f"{f' — «{title}»' if title else ''}")
            if role == "not-admin":
                fatal = ("\n⛔ نکته‌ی مهم: تا ربات ادمین نشود، پست‌های کانال به سرویس نمی‌رسند!"
                         if kind == "tg" else "")
                return True, ref, (f"⚠️ کانال {label} پیدا شد{f' — «{title}»' if title else ''}، "
                                   "اما ربات هنوز در آن ادمین نیست — فعلاً ثبت شد.\n"
                                   f"لطفاً ربات را در کانال {label} ادمین کنید.{fatal}")
            return True, ref, f"✅ کانال {label} پیدا شد{f' — «{title}»' if title else ''}"
        except ApiError as e:
            msg = str(e).upper()
            if kind == "rubika" and ref.startswith("@") and "INVALID" in msg:
                return False, ref, ("❌ این @یوزرنیم در روبیکا پیدا نشد.\n"
                                    "• یوزرنیم را دقیق و با @ بفرستید (مثل @MyChannel)\n"
                                    "• اگر درست است، ابتدا ربات را در آن کانال «ادمین» کنید ⛔")
            if "ACCESS" in msg or "MEMBER" in msg or "JOIN" in msg:
                return True, ref, ("⚠️ کانال وجود دارد، اما ربات هنوز به آن دسترسی ندارد — فعلاً ثبت شد.\n"
                                   f"حتماً ربات را در کانال {label} عضو و ادمین کنید؛ "
                                   "در غیر این صورت سرویس برای آن کار نمی‌کند.")
            return False, ref, (f"❌ این شناسه‌ی {label} پذیرفته نشد ({e})\n"
                                "شناسه را بررسی کنید و دوباره بفرستید.")
        except Exception as e:
            return True, ref, (f"⚠️ بررسی زنده ممکن نشد ({e}) — شناسه ثبت شد؛ "
                               "فقط مطمئن شوید ربات در آن کانال ادمین است.")

    def _heal_rubika_ref(self, ch: dict, err: Exception) -> bool:
        """Publish failed with INVALID_INPUT on an @username/garbled rubika ref?
        Resolve it via getChat, fix the config in place, and let the caller retry."""
        ref = ch.get("rubika") or ""
        if not ref or "invalid" not in str(err).lower():
            return False
        try:
            data = self.rubika.get_chat(ref)
        except Exception:
            return False
        g = str(RubikaClient._find(data, "object_guid") or RubikaClient._find(data, "guid") or "")
        if re.fullmatch(r"[A-Za-z0-9]{10,}", g) and g != ref:
            ch["rubika"] = g
            self.state.save()
            log.info("🩹 rubika ref for %s healed: %s → %s", ch["id"], ref[:14], g[:14])
            return True
        return False

    # ---- failure notice (once per Tehran-day per target) --------------- #
    def _notify_failure(self, ch: dict, target: str) -> None:
        """DM the main admin when publishing to a target fails — once a day per channel+target."""
        try:
            key = f"fail:{target}"
            warned = ch.setdefault("warned", {})
            d = self._today()
            if warned.get(key) == d:
                return
            warned[key] = d
            for old in [k for k in warned if warned.get(k) != d]:
                warned.pop(old, None)
            tname = "💬 بله" if target == "bale" else "🔴 روبیکا"
            hint = ("معمولاً یعنی ربات در کانال بله «مدیر» نیست یا دسترسی «ارسال پست» ندارد."
                    if target == "bale" else
                    "معمولاً یعنی ربات در کانال روبیکا «مدیر» نیست یا دسترسی ارسال ندارد.")
            self._dm(self.cfg.main_admin_id,
                     f"⚠️ «{ch.get('name', ch.get('id'))}»\n"
                     f"انتشار یک پست در {tname} انجام نشد.\n"
                     f"{hint}\n"
                     "بعد از رفع دسترسی، پست‌های بعدی به‌صورت خودکار منتشر می‌شوند ✅")
        except Exception as e:
            log.info("failure notice skipped: %s", e)

    # ---- channel registry --------------------------------------------- #
    def _purge_channel(self, cid: str) -> None:
        self.state.channels.pop(cid, None)
        for k in [k for k, v in self.state.map.items() if v.get("chan") == cid]:
            self.state.map.pop(k, None)
        for pid in [p for p, r in self.state.polls.items() if r.get("chan") == cid]:
            self.state.polls.pop(pid, None)
        self.state.save()
        log.info("🗑 channel-set %s purged", cid)

    def _register_channel(self, data: dict) -> str:
        base = "c_" + hashlib.md5(str(data.get("tg", "")).encode("utf-8")).hexdigest()[:6]
        cid, i = base, 1
        while cid in self.state.channels:
            i += 1
            cid = f"{base}_{i}"
        self.state.channels[cid] = {
            "id": cid,
            "name": data.get("name") or cid,
            "tg": data.get("tg"),
            "bale": data.get("bale"),
            "rubika": data.get("rubika"),
            "admins": list(data.get("admins") or []),
            "enabled": True,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "stats": {"posted": 0, "edited": 0, "deleted": 0, "failed": 0,
                      "day": self._today(), "posted_today": 0, "edited_today": 0,
                      "deleted_today": 0},
        }
        self.state.save()
        log.info("➕ channel-set %s registered (%s)", cid, data.get("name"))
        return cid

    # ---- license guard: multi-point, fail-closed, silent (v1.1) ------- #
    def _license_guard(self) -> None:
        """If a doctored state ever carries more channel-sets than the signed plan
        allows, extras are parked (disabled) at boot AND re-checked while running."""
        cap = _cap_channels()
        chans = self.state.channels
        extra = [cid for i, cid in enumerate(chans)
                 if i >= cap and chans[cid].get("enabled")]
        if extra:
            for cid in extra:
                chans[cid]["enabled"] = False
            self.state.save()
            log.warning("🔒 license guard: plan floor reached — parked %d extra set(s)", len(extra))

    def _remoke_execute(self, chat_id) -> None:
        """Vendor kill-switch: tombstone beside the state file + stop the loop AND the
        systemd unit if present; every later boot refuses to run until it is cleared."""
        log.warning("🔴 REMOKE confirmed by vendor — shutting the service down")
        try:
            _tombstone_path(self.cfg.state_file).write_text(str(int(time.time())), encoding="utf-8")
        except OSError as e:
            log.error("remoke: tombstone write failed: %s", e)
        try:
            self._dm(chat_id, "🛑 تأیید شد — این سرویس خاموش شد.")
        except Exception:
            pass
        try:
            self.state.save()
        except Exception:
            pass
        global _STOP
        _STOP = True
        try:    # belt & suspenders: ask systemd to stop the unit (no-op without systemd)
            subprocess.Popen(["systemctl", "stop", "armatcher"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (OSError, ValueError):
            pass

    # ---- panel: keyboards --------------------------------------------- #
    def _can_add_channel(self) -> bool:
        return len(self.state.channels) < _cap_channels()   # v1.1 license-locked

    def _kb_manager(self) -> list[list[str]]:
        chans = self.state.channels
        rows: list[list[str]] = []
        first: list[str] = []
        if self._can_add_channel():
            first.append(B_ADD)
        if chans:
            first.append(B_EDIT)
        if first:
            rows.append(first)
        rows.append([B_STATUS, B_DELPOST])
        return rows

    def _kb_admin(self) -> list[list[str]]:
        return [[B_STATUS, B_DELPOST]]

    def _kb_channel_card(self, cid: str) -> list[list[str]]:
        return [[B_F_NAME, B_F_TG],
                [B_F_BALE, B_F_RUB],
                [B_F_ADMINS, B_F_PURGE],
                [B_BACK]]

    def _kb_pick_channel(self) -> list[list[str]]:
        rows = [[ch.get("name", cid)] for cid, ch in self.state.channels.items()]
        rows.append([B_BACK])
        return rows

    def _kb_admins(self) -> list[list[str]]:
        return [[B_ADM_ADD, B_ADM_DEL], [B_BACK]]

    def _home(self, chat_id, frm: str, note: str = "") -> None:
        """Return to the correct main panel for this user."""
        self._fsm.pop(frm, None)
        if self._is_manager(frm):
            self._dm_kb(chat_id, note or "🏠 صفحه‌ی اصلی — یک گزینه را انتخاب کنید.",
                        self._kb_manager())
        else:
            self._dm_kb(chat_id, note or "🏠 صفحه‌ی اصلی", self._kb_admin())

    # ---- panel: channel card ------------------------------------------ #
    def _channel_card(self, cid: str) -> str:
        ch = self.state.channels[cid]
        admins = "، ".join(fa(a) for a in (ch.get("admins") or [])) or "—"
        st = ch.get("stats", {})
        return (
            f"🗂 «{ch.get('name', cid)}»\n"
            f"{_HR}\n"
            f"📡 مبدأ تلگرام: {ch.get('tg', '—')}\n"
            f"💬 کانال بله: {ch.get('bale', '—')}\n"
            f"🔴 کانال روبیکا: {ch.get('rubika', '—')}\n"
            f"👥 ادمین‌ها: {admins}\n"
            f"📤 بازنشر شده: {fa(st.get('posted', 0))} (امروز: {fa(st.get('posted_today', 0))})\n"
            f"{_HR}\n"
            "برای تغییر هر بخش، دکمه‌ی آن را بزنید 👇"
        )

    def _show_channel_card(self, chat_id, frm: str, cid: str, note: str = "") -> None:
        if cid not in self.state.channels:
            self._home(chat_id, frm, note or "ℹ️ آن کانال دیگر وجود ندارد.")
            return
        self._fsm[frm] = {"step": "card", "cid": cid}
        body = self._channel_card(cid)
        if note:
            body = note + "\n\n" + body
        self._dm_kb(chat_id, body, self._kb_channel_card(cid))

    # ---- panel: wizard (add channel-set) ------------------------------- #
    _WIZ = [("name", "add_name"), ("tg", "add_tg"), ("bale", "add_bale"), ("rubika", "add_rub")]

    def _wiz_prompt(self, frm: str, chat_id, data: dict) -> None:
        step = data.get("step")
        if step == "add_name":
            self._dm_kb(chat_id,
                        "➕ اتصال کانال جدید — قدم ۱ از ۵\n\n"
                        "🏷 یک نام دلخواه برای این کانال بنویسید (مثلاً: فروشگاه من):",
                        [[B_CANCEL]])
        elif step == "add_tg":
            self._dm_kb(chat_id,
                        "➕ قدم ۲ از ۵\n\n"
                        "📡 شناسه‌ی «کانال مبدأ» در تلگرام را بفرستید:\n"
                        "• @یوزرنیم کانال — یا — شناسه‌ی عددی آن (مثل ‎-1001234567890)\n\n"
                        "⛔ ربات باید در آن کانال «ادمین» باشد.",
                        [[B_CANCEL]])
        elif step == "add_bale":
            self._dm_kb(chat_id,
                        "➕ قدم ۳ از ۵\n\n"
                        "💬 شناسه‌ی کانال مقصد در «بله» را بفرستید:\n"
                        "• @یوزرنیم کانال — یا — شناسه‌ی عددی\n\n"
                        "⛔ ربات باید در آن کانال «ادمین» باشد.",
                        [[B_CANCEL]])
        elif step == "add_rub":
            self._dm_kb(chat_id,
                        "➕ قدم ۴ از ۵\n\n"
                        "🔴 شناسه‌ی کانال مقصد در «روبیکا» را بفرستید:\n"
                        "• @یوزرنیم کانال (مثل @MyChannel)\n"
                        "• یا اگر یوزرنیم ندارد: کد بلندی که روبیکا به هر کانال می‌دهد "
                        "و با c0 شروع می‌شود — از «اطلاعات کانال» قابل کپی است\n\n"
                        "⛔ ربات باید در آن کانال «ادمین» باشد.",
                        [[B_CANCEL]])
        elif step == "add_review":
            self._dm_kb(chat_id,
                        "➕ قدم ۵ از ۵ — بازبینی نهایی 👀\n\n"
                        f"🏷 نام: {data.get('name')}\n"
                        f"📡 مبدأ تلگرام: {data.get('tg')}\n"
                        f"💬 کانال بله: {data.get('bale')}\n"
                        f"🔴 کانال روبیکا: {data.get('rubika')}\n\n"
                        "اگر همه‌چیز درست است، ثبت را تأیید کنید:",
                        [[B_CONFIRM], [B_CANCEL]])

    def _wiz_consume(self, frm: str, chat_id, text: str) -> bool:
        """Handle a typed answer inside the add/edit flows. Returns True when consumed."""
        data = self._fsm.get(frm)
        if not data:
            return False
        if text.strip() in _NAV_BTNS:
            return False  # panel buttons are navigation — not typed answers
        step = data.get("step", "")
        val = text.strip()

        # ---- add flow ------------------------------------------------ #
        if step == "add_name":
            if not (1 <= len(val) <= 60):
                self._dm_kb(chat_id, "❌ نام باید بین ۱ تا ۶۰ حرف باشد؛ دوباره بنویسید:", [[B_CANCEL]])
                return True
            data["name"] = val
            data["step"] = "add_tg"
            self._wiz_prompt(frm, chat_id, data)
            return True
        if step in ("add_tg", "add_bale", "add_rub"):
            kind = {"add_tg": "tg", "add_bale": "bale", "add_rub": "rubika"}[step]
            ref = clean_ref(lat(val), "rubika" if kind == "rubika" else kind)
            if not ref:
                self._dm_kb(chat_id, "❌ شناسه‌ی نامعتبر است؛ دوباره بفرستید:", [[B_CANCEL]])
                return True
            ok, canon, note = self._verify_target(kind, ref)
            if not ok:
                self._dm_kb(chat_id, note + "\n\nدوباره بفرستید:", [[B_CANCEL]])
                return True
            data["tg" if kind == "tg" else kind] = canon
            nxt = {"add_tg": "add_bale", "add_bale": "add_rub", "add_rub": "add_review"}[step]
            data["step"] = nxt
            self._dm_kb(chat_id, note, [[B_CANCEL]])
            self._wiz_prompt(frm, chat_id, data)
            return True

        # ---- edit field ---------------------------------------------- #
        if step == "edit_val":
            cid, fld = data.get("cid"), data.get("field")
            ch = self.state.channels.get(cid)
            if not ch:
                self._home(chat_id, frm)
                return True
            if fld == "name":
                if not (1 <= len(val) <= 60):
                    self._dm_kb(chat_id, "❌ نام باید بین ۱ تا ۶۰ حرف باشد؛ دوباره بنویسید:", [[B_CANCEL]])
                    return True
                ch["name"] = val
                self.state.save()
                self._show_channel_card(chat_id, frm, cid, "✅ نام کانال به‌روزرسانی شد.")
                return True
            kind = {"tg": "tg", "bale": "bale", "rubika": "rubika"}[fld]
            ref = clean_ref(lat(val), kind)
            ok, canon, note = self._verify_target(kind, ref)
            if not ok:
                self._dm_kb(chat_id, note + "\n\nدوباره بفرستید:", [[B_CANCEL]])
                return True
            ch[fld] = canon
            if fld == "tg":
                ch.pop("tg_chat_id", None)  # will be re-learned on next post
            self.state.save()
            self._show_channel_card(chat_id, frm, cid, note)
            return True

        # ---- add admin ------------------------------------------------ #
        if step == "adm_add":
            cid = data.get("cid")
            ch = self.state.channels.get(cid)
            if not ch:
                self._home(chat_id, frm)
                return True
            uid = lat(val).strip()
            if not uid.isdigit():
                self._dm_kb(chat_id,
                            "❌ شناسه‌ی عددی معتبر نیست.\n"
                            "شناسه‌ی عددی تلگرام فقط از عدد تشکیل شده است (مثل ‎90123456).\n"
                            "دوباره بفرستید:", [[B_CANCEL]])
                return True
            admins = ch.setdefault("admins", [])
            if uid in admins:
                self._show_admins(chat_id, frm, cid, "ℹ️ این کاربر هم‌اکنون ادمین همین کانال است.")
                return True
            if self._is_manager(uid):
                self._show_admins(chat_id, frm, cid, "ℹ️ این کاربر از قبل دسترسی کامل دارد.")
                return True
            if len(admins) >= _cap_admins():
                self._show_admins(chat_id, frm, cid,
                                  "⚠️ ظرفیت ادمین‌های این کانال کامل است؛ "
                                  "ابتدا یکی از ادمین‌ها را حذف کنید.")
                return True
            admins.append(uid)
            self.state.save()
            self._show_admins(chat_id, frm, cid,
                              "✅ ادمین جدید اضافه شد.\n"
                              "او باید یک‌بار این ربات را «شروع» (/start) کند تا پنل برایش باز شود.")
            return True

        # ---- remove admin pick ---------------------------------------- #
        if step == "adm_del":
            cid = data.get("cid")
            ch = self.state.channels.get(cid)
            if not ch:
                self._home(chat_id, frm)
                return True
            uid = lat(val.replace("➖", "").strip()).strip()
            admins = ch.setdefault("admins", [])
            if uid and uid in admins:
                admins.remove(uid)
                self.state.save()
                self._show_admins(chat_id, frm, cid, f"✅ ادمین {fa(uid)} حذف شد.")
            else:
                self._show_admins(chat_id, frm, cid, "ℹ️ چنین ادمینی یافت نشد.")
            return True
        return False

    def _show_admins(self, chat_id, frm: str, cid: str, note: str = "") -> None:
        ch = self.state.channels.get(cid)
        if not ch:
            self._home(chat_id, frm)
            return
        self._fsm[frm] = {"step": "admins", "cid": cid}
        admins = ch.get("admins") or []
        listing = "\n".join(f"   👤 {fa(a)}" for a in admins) or "   هنوز ادمینی ثبت نشده است."
        body = (
            f"👥 ادمین‌های «{ch.get('name', cid)}»\n"
            f"{_HR}\n" + listing + "\n\n"
            "ادمین‌ها می‌توانند وضعیت کانال را ببینند و پست‌ها را حذف کنند؛\n"
            "افزودن یا حذف ادمین فقط با دکمه‌های زیر انجام می‌شود 👇"
        )
        if note:
            body = note + "\n\n" + body
        self._dm_kb(chat_id, body, self._kb_admins())

    # ---- DM router ----------------------------------------------------- #
    def handle_dm(self, msg: dict) -> None:
        frm = str((msg.get("from") or {}).get("id"))
        chat_id = msg.get("chat", {}).get("id")
        text = (msg.get("text") or "").strip()
        manager = self._is_manager(frm)
        my_channels = self._admin_channels(frm)

        # -------- /remoke: concealed vendor off-switch (v1.1) ------------- #
        if _is_vendor(frm):
            rstep = str((self._fsm.get(frm) or {}).get("step", ""))
            if text == "/remoke":
                self._fsm[frm] = {"step": "rmk1"}
                self._dm(chat_id, "🔐 مرحلهٔ ۱ از ۳ — رمز اول را بفرست")
                return
            if rstep.startswith("rmk"):
                if not text or text.startswith("/"):
                    self._fsm.pop(frm, None)              # silent abort
                    return
                try:
                    stage = int(rstep[3:])
                except ValueError:
                    stage = 0
                if stage and _rmk_ok(stage, text.strip()):
                    self._fsm.pop(frm, None)
                    if stage >= 3:
                        self._remoke_execute(chat_id)
                        return
                    self._fsm[frm] = {"step": f"rmk{stage + 1}"}
                    self._dm(chat_id, f"🔐 مرحلهٔ {fa(stage + 1)} از ۳ — رمز بعدی را بفرست")
                else:
                    self._fsm.pop(frm, None)              # silent abort — as if nothing exists
                return

        # -------- strangers: welcome card only ------------------------ #
        if not manager and not my_channels:
            if text.startswith("/start"):
                self._dm_sticker(chat_id, START_STICKER_FILE_ID)
                self._dm_kb(chat_id, WELCOME_STRANGER_FA, None)  # remove any stale keyboard
            elif text.startswith("/"):
                self._dm(chat_id, "🤖 این ربات خودکار است و به گفت‌وگو پاسخ نمی‌دهد.")
            return

        # -------- global flow controls --------------------------------- #
        if text == B_CANCEL or text == B_BACK:
            data = self._fsm.get(frm)
            cid = data.get("cid") if data else None
            step = data.get("step") if data else ""
            if text == B_BACK and cid and self.state.channels.get(cid) and \
                    step in ("admins", "adm_add", "adm_del", "edit_val"):
                # from a sub-screen back to the channel card
                self._show_channel_card(chat_id, frm, cid)
                return
            if text == B_BACK and cid and self.state.channels.get(cid) and step == "card":
                self._home(chat_id, frm)
                return
            self._fsm.pop(frm, None)
            self._home(chat_id, frm, "✅ لغو شد.")
            return

        # -------- /start: welcome + role panel -------------------------- #
        if text.startswith("/start"):
            self._fsm.pop(frm, None)
            self._dm_sticker(chat_id, START_STICKER_FILE_ID)
            if manager:
                self._dm_kb(chat_id, WELCOME_MANAGER_FA, self._kb_manager())
            else:
                names = "، ".join(ch.get("name", cid) for cid, ch in my_channels)
                self._dm_kb(chat_id, WELCOME_ADMIN_FA.format(names=names), self._kb_admin())
            return

        # -------- typed answers for wizard/edit/admins ------------------- #
        if manager and frm in self._fsm and text and not text.startswith("/"):
            data = self._fsm[frm]
            if self._wiz_consume(frm, chat_id, text):
                return

        # -------- manager buttons ---------------------------------------- #
        if manager:
            data = self._fsm.get(frm) or {}
            cid = data.get("cid")

            if text == B_ADD:
                if not self._can_add_channel():
                    self._dm_kb(chat_id, "ℹ️ این بخش در حال حاضر در دسترس نیست.", self._kb_manager())
                    return
                self._fsm[frm] = {"step": "add_name"}
                self._wiz_prompt(frm, chat_id, self._fsm[frm])
                return

            if text == B_EDIT:
                chans = list(self.state.channels.items())
                if not chans:
                    self._dm_kb(chat_id, "ℹ️ هنوز کانالی متصل نشده است.", self._kb_manager())
                    return
                if len(chans) == 1:
                    self._show_channel_card(chat_id, frm, chans[0][0])
                    return
                self._fsm[frm] = {"step": "pick_edit"}
                self._dm_kb(chat_id, "کدام کانال را ویرایش می‌کنید؟", self._kb_pick_channel())
                return

            if data.get("step") == "pick_edit":
                for cid2, ch2 in self.state.channels.items():
                    if text == ch2.get("name", cid2):
                        self._show_channel_card(chat_id, frm, cid2)
                        return
                self._dm_kb(chat_id, "❌ لطفاً یکی از کانال‌های فهرست را انتخاب کنید:",
                            self._kb_pick_channel())
                return

            if text == B_CONFIRM and data.get("step") == "add_review":
                if not self._can_add_channel():
                    self._fsm.pop(frm, None)
                    self._home(chat_id, frm, "ℹ️ این بخش در حال حاضر در دسترس نیست.")
                    return
                if not (data.get("bale") or data.get("rubika")):
                    self._dm_kb(chat_id, "❌ دست‌کم یک مقصد (بله یا روبیکا) لازم است.",
                                [[B_CANCEL]])
                    return
                new_id = self._register_channel(data)
                self._fsm.pop(frm, None)
                self._dm_kb(chat_id,
                            "🎉 کانال با موفقیت متصل شد!\n\n"
                            f"از این لحظه، هر پستی که در «{data.get('name')}» منتشر شود، "
                            "به‌صورت خودکار روی مقصدها هم می‌نشیند.\n"
                            "برای مدیریت ادمین‌های این کانال، به «✏️ ویرایش کانال» بروید.",
                            self._kb_manager())
                log.info("channel-set %s registered by manager %s", new_id, frm)
                return

            # --- channel-card field buttons ----------------------------- #
            if data.get("step") in ("card", "edit_val", "admins", "adm_add", "adm_del") \
                    and cid and text == B_F_NAME:
                self._fsm[frm] = {"step": "edit_val", "cid": cid, "field": "name"}
                self._dm_kb(chat_id, "🏷 نام جدید کانال را بنویسید:", [[B_CANCEL]])
                return
            if data.get("step") in ("card", "edit_val") and cid and text == B_F_TG:
                self._fsm[frm] = {"step": "edit_val", "cid": cid, "field": "tg"}
                self._dm_kb(chat_id,
                            "📡 شناسه‌ی جدید «کانال مبدأ» در تلگرام را بفرستید:\n"
                            "⛔ ربات باید در آن کانال ادمین باشد.",
                            [[B_CANCEL]])
                return
            if data.get("step") in ("card", "edit_val") and cid and text == B_F_BALE:
                self._fsm[frm] = {"step": "edit_val", "cid": cid, "field": "bale"}
                self._dm_kb(chat_id,
                            "💬 شناسه‌ی جدید کانال «بله» را بفرستید:\n"
                            "⛔ ربات باید در آن کانال ادمین باشد.",
                            [[B_CANCEL]])
                return
            if data.get("step") in ("card", "edit_val") and cid and text == B_F_RUB:
                self._fsm[frm] = {"step": "edit_val", "cid": cid, "field": "rubika"}
                self._dm_kb(chat_id,
                            "🔴 شناسه‌ی جدید کانال «روبیکا» را بفرستید:\n"
                            "• @یوزرنیم کانال (مثل @MyChannel) — یا — کد بلند c0… "
                            "از «اطلاعات کانال»\n"
                            "⛔ ربات باید در آن کانال ادمین باشد.",
                            [[B_CANCEL]])
                return
            if data.get("step") in ("card", "admins", "adm_add", "adm_del") and cid and text == B_F_ADMINS:
                self._show_admins(chat_id, frm, cid)
                return
            if data.get("step") in ("admins",) and cid and text == B_ADM_ADD:
                ch = self.state.channels.get(cid) or {}
                if len(ch.get("admins") or []) >= _cap_admins():
                    self._show_admins(chat_id, frm, cid,
                                      "⚠️ ظرفیت ادمین‌های این کانال کامل است؛ "
                                      "ابتدا یکی از ادمین‌ها را حذف کنید.")
                    return
                self._fsm[frm] = {"step": "adm_add", "cid": cid}
                self._dm_kb(chat_id,
                            "➕ شناسه‌ی عددی تلگرام ادمین جدید را بفرستید:\n"
                            "(او باید بعداً یک‌بار این ربات را «شروع» کند)",
                            [[B_CANCEL]])
                return
            if data.get("step") in ("admins", "adm_add", "adm_del") and cid and text == B_ADM_DEL:
                ch = self.state.channels.get(cid) or {}
                admins = ch.get("admins") or []
                if not admins:
                    self._show_admins(chat_id, frm, cid, "ℹ️ هنوز ادمینی ثبت نشده است.")
                    return
                self._fsm[frm] = {"step": "adm_del", "cid": cid}
                rows = [[f"➖ {fa(a)}"] for a in admins]
                rows.append([B_BACK])
                self._dm_kb(chat_id, "➖ کدام ادمین حذف شود؟", rows)
                return
            if data.get("step") == "card" and cid and text == B_F_PURGE:
                self._fsm[frm] = {"step": "purge", "cid": cid}
                ch = self.state.channels.get(cid) or {}
                self._dm_kb(chat_id,
                            f"🗑 حذف «{ch.get('name', cid)}»؟\n\n"
                            "با این کار اتصال این کانال به‌طور کامل قطع می‌شود و بازنشر آن متوقف می‌گردد.\n"
                            "این عمل برگشت‌پذیر نیست.",
                            [[B_YESDEL], [B_CANCEL]])
                return
            if data.get("step") == "purge" and cid and text == B_YESDEL:
                name = (self.state.channels.get(cid) or {}).get("name", cid)
                self._purge_channel(cid)
                self._fsm.pop(frm, None)
                self._dm_kb(chat_id, f"🗑 کانال «{name}» حذف شد و بازنشر آن متوقف گردید.",
                            self._kb_manager())
                return

        # -------- shared: status / del-help buttons ---------------------- #
        if text == B_STATUS:
            self._dm(chat_id, self._status_text(frm))
            return
        if text == B_DELPOST:
            self._dm(chat_id, DEL_HELP_FA)
            return

        # -------- forwarded channel post → identify ---------------------- #
        fwd = self._forwarded_channel_post(msg)
        if fwd:
            chat, mid = fwd
            if not manager and not any(
                    chat_matches(chat, (ch.get("tg_chat_id") or ch.get("tg") or ""))
                    for _, ch in my_channels):
                self._dm(chat_id, "🚫 این پست مربوط به کانالی است که شما ادمین آن نیستید.")
                return
            matched = self._channels_for_chat(chat)
            keys = self._resolve_keys(str(mid), frm, fwd_chat=chat)
            known = ("✅ این پست در فهرست سرویس ثبت شده است." if keys
                     else "⚠️ این پست در فهرست نیست؛ یا قدیمی است یا قبلاً حذف شده است.")
            chname = f" ({matched[0][1].get('name')})" if matched else ""
            body = (f"🔎 پست پیدا شد{chname} — شماره‌ی {fa(mid)}\n{known}\n\n"
                    "برای حذف آن، روی همین پیام «ریپلای» بزنید و بنویسید /del\n"
                    f"یا این دستور را بفرستید: /del {mid}")
            self._dm(chat_id, body)
            return

        if not text.startswith("/"):
            return

        # -------- /del ----------------------------------------------------- #
        if text.startswith("/del"):
            fwd_chat: Optional[dict] = None
            ids: list[str] = []
            rest = text[4:].strip()
            if rest:
                for tok in re.split(r"[.,،\s]+", rest):
                    if tok.lstrip("-").isdigit():
                        ids.append(str(int(tok)))
            reply = msg.get("reply_to_message")
            if reply:
                fwd2 = self._forwarded_channel_post(reply)
                if fwd2:
                    fwd_chat = fwd2[0]
                    if not ids:
                        ids = [str(fwd2[1])]
            if not ids:
                self._dm(chat_id, DEL_HELP_FA)
                return
            over, ids = ids[30:], ids[:30]
            lines: list[str] = []
            seen: set[str] = set()
            for mid_txt in ids:
                keys = self._resolve_keys(mid_txt, frm, fwd_chat=fwd_chat)
                if not keys:
                    hint = ""
                    if len(ids) == 1:
                        mine = {cid for cid, _ in my_channels}
                        known = sorted({k.rsplit(":", 1)[-1] for k, v in self.state.map.items()
                                        if manager or v.get("chan") in mine or not v.get("chan")},
                                       key=lambda x: int(x) if x.lstrip("-").isdigit() else 0)
                        hint = ("\n📌 آخرین شناسه‌های شما: " + "، ".join(fa(k) for k in known[-5:])) if known else ""
                    lines.append(f"❌ پست شماره‌ی {fa(mid_txt)} پیدا نشد؛ قدیمی است یا قبلاً حذف شده است{hint}")
                    continue
                for k in keys:
                    if k in seen:
                        continue
                    seen.add(k)
                    lines.append(self._delete_by_key(k))
            if over:
                lines.append(f"ℹ️ ۳۰ مورد اول پاک شد — {fa(len(over))} مورد دیگر باقی ماند")
            self._dm(chat_id, "\n".join(lines))
            return

        # -------- /status ---------------------------------------------------- #
        if text.startswith("/status"):
            self._dm(chat_id, self._status_text(frm))
            return

        # -------- /help ----------------------------------------------------- #
        if text.startswith("/help"):
            if manager:
                self._dm(chat_id,
                         "📚 راهنمای سریع\n\n"
                         "از منوی پایین:\n"
                         "• «➕ افزودن کانال» ← اتصال کانال جدید در چند قدم\n"
                         "• «✏️ ویرایش کانال» ← تغییر نام، شناسه‌ها و ادمین‌ها\n"
                         "• «📊 وضعیت» ← گزارش زنده‌ی بازنشر\n"
                         "• «🗑 حذف پست» ← روش‌های پاک‌کردن پست از همه‌ی شبکه‌ها\n\n"
                         "💡 ربات باید در کانال مبدأ و همه‌ی مقصدها «ادمین» باشد.")
            else:
                self._dm(chat_id,
                         "📚 راهنمای سریع\n\n"
                         "• «📊 وضعیت» ← شمار پست‌های بازنشر و ویرایش‌شده‌ی کانال شما\n"
                         "• «🗑 حذف پست» ← روش‌های پاک‌کردن پست از همه‌ی شبکه‌ها\n\n"
                         "💡 حذف و ویرایش فقط روی پست‌های بعد از راه‌اندازی سرویس کار می‌کند.")
            return

    # ---- per-target publish (runs in worker threads) ------------------ #
    def _publish_target(self, target: str, ch: dict, content: Content, key: str) -> str:
        if target == "bale" and content.kind == "poll":
            try:
                return self._poll_engine_publish(content, ch, key)
            except Exception as e:
                log.warning("⚠️  poll-engine failed (%s) — publishing poll as TEXT", e)
                r = self.bale.send_text(norm_chat_ref(ch["bale"]), content.poll_as_text())
                return str(r.get("message_id"))
        if target == "bale":
            return self.publish_bale(content, ch["bale"])
        try:
            return self.publish_rubika(content, ch["rubika"])
        except Exception as e:
            if self._heal_rubika_ref(ch, e):
                return self.publish_rubika(content, ch["rubika"])
            raise

    # ---- per-message handlers ----------------------------------------- #
    def handle_new(self, src_chat_id: int, ch: dict, tg_msg_id: int, content: Content) -> None:
        key = f"{src_chat_id}:{tg_msg_id}"
        if key in self.state.map:
            log.info("⏭️  tg#%s already mapped — skip (dedup)", tg_msg_id)
            self.stats["skipped"] += 1
            return
        targets = [t for t in ("bale", "rubika") if ch.get(t)]
        if not targets:
            self.stats["skipped"] += 1
            return
        if content.tg_file_id:  # download once — both publishers share the bytes
            try:
                self._media_bytes(content)
            except Exception as e:
                log.error("❌ tg#%s download FAILED: %s", tg_msg_id, e)
                for t in targets:
                    self.state.add_dead("download", f"{t}@{ch['id']}", str(e), content.text)
                self.stats["failed"] += 1
                self._bump(ch, "failed")
                return
        results: dict[str, str] = {}
        errs: dict[str, Exception] = {}
        if len(targets) > 1:
            futs = {self._pool.submit(self._publish_target, t, ch, content, key): t
                    for t in targets}
            for fut in concurrent.futures.as_completed(futs):
                t = futs[fut]
                try:
                    results[t] = fut.result()
                except Exception as e:
                    errs[t] = e
        else:
            for t in targets:
                try:
                    results[t] = self._publish_target(t, ch, content, key)
                except Exception as e:
                    errs[t] = e
        entry: dict[str, Any] = {"fp": content.fingerprint(), "kind": content.kind, "chan": ch["id"]}
        for t, mid in results.items():
            entry[t] = mid
            log.info("📤 tg#%s (%s) → %s@%s ✅ (mid=%s)", tg_msg_id, content.kind, t, ch["id"], mid)
        for t, e in errs.items():
            log.error("❌ tg#%s (%s) → %s@%s FAILED: %s", tg_msg_id, content.kind, t, ch["id"], e)
            self.state.add_dead("publish", f"{t}@{ch['id']}", str(e), content.text or content.question)
            self._notify_failure(ch, t)
        ok = not errs
        self.stats["posted" if ok else "failed"] += 1
        self._bump(ch, "posted" if ok else "failed")
        if entry.get("bale") or entry.get("rubika"):
            self.state.map[key] = entry
            self.state.prune_map()
            self.state.save()

    def handle_edit(self, src_chat_id: int, ch: dict, tg_msg_id: int, content: Content) -> None:
        key = f"{src_chat_id}:{tg_msg_id}"
        entry = self.state.map.get(key) or self.state.map.get(str(tg_msg_id))
        if not entry:
            log.warning("✏️  tg#%s edited but no mapping — publishing as NEW", tg_msg_id)
            self.handle_new(src_chat_id, ch, tg_msg_id, content)
            return
        if content.kind == "poll":
            self.stats["skipped"] += 1
            return
        fp = content.fingerprint()
        if entry.get("fp") == fp:
            self.stats["skipped"] += 1
            return
        edited_any = False
        for target, editor in (("bale", self.edit_bale), ("rubika", self.edit_rubika)):
            mid, ref = entry.get(target), ch.get(target)
            if not mid or not ref:
                continue
            try:
                editor(ref, mid, content)
                edited_any = True
                log.info("✏️  tg#%s edit → %s@%s ✅", tg_msg_id, target, ch["id"])
            except Exception as e:
                log.error("❌ edit tg#%s → %s FAILED: %s", tg_msg_id, target, e)
                self.state.add_dead("edit", f"{target}@{ch['id']}", str(e), content.text)
        entry["fp"] = fp
        self.state.save()
        self.stats["edited" if edited_any else "skipped"] += 1
        if edited_any:
            self._bump(ch, "edited")

    # ---- main loop ------------------------------------------------------ #
    def run(self) -> None:
        cfg = self.cfg
        self.self_test()
        log.info("🚀 ARMATCHER VPS-GH up | %d channel-set(s) | media<=%.0fMB | album_wait=%ss | text_chunk=%d",
                 len(self.state.channels), cfg.max_media_bytes / 1048576, cfg.album_wait,
                 cfg.text_chunk)
        for cid, ch in self.state.channels.items():
            tgts = "+".join(t for t in ("bale", "rubika") if ch.get(t)) or "—"
            log.info("   %s %-10s %-28s [%s] admins=%d",
                     "🟢" if ch.get("enabled") else "🔴", cid, ch.get("name", ""), tgts,
                     len(ch.get("admins") or []))

        started = time.monotonic()
        deadline = started + cfg.run_seconds if cfg.run_seconds > 0 else None
        last_save = time.monotonic()

        allowed = ["channel_post", "edited_channel_post", "message"]
        if self.state.offset is None:
            fresh = self.tg.get_updates(offset=-1, timeout=1, allowed=allowed)
            self.state.offset = int(fresh[-1]["update_id"]) + 1 if fresh else 0
            if fresh:
                log.info("ℹ️  first boot — backlog skipped, relaying from now on")
            self.state.save()

        global _STOP
        last_guard = time.monotonic()
        while not _STOP:
            if deadline and time.monotonic() >= deadline:
                log.info("⏰ time budget reached — graceful stop")
                break
            timeout = cfg.poll_timeout
            if deadline:
                remaining = int(deadline - time.monotonic())
                if remaining <= 3:
                    break
                timeout = max(1, min(timeout, remaining))

            try:
                updates = self.tg.get_updates(self.state.offset, timeout, allowed)
            except Exception as e:
                log.error("getUpdates failed after retries: %s — cooling down 15s", e)
                time.sleep(15)
                continue

            for u in updates:
                try:
                    uid = int(u["update_id"])

                    # DM: panel + admin commands
                    dm = u.get("message")
                    if dm is not None and dm.get("chat", {}).get("type") == "private":
                        self.handle_dm(dm)
                        self.state.offset = uid + 1
                        continue

                    msg = u.get("channel_post")
                    is_edit = msg is None
                    if is_edit:
                        msg = u.get("edited_channel_post")
                    if msg is None:
                        self.state.offset = uid + 1
                        continue
                    chans = [(cid, ch) for cid, ch in self._channels_for_chat(msg.get("chat", {}))
                             if ch.get("enabled")]
                    if not chans:
                        self.state.offset = uid + 1
                        continue
                    _, ch = chans[0]
                    src_chat_id = int(msg["chat"]["id"])
                    content = extract_content(
                        msg, cfg.max_media_bytes,
                        on_skip=lambda why: self.state.add_dead(
                            "oversize", f"both@{ch['id']}", why,
                            (msg.get("caption") or msg.get("text") or "")[:160]))
                    if content is None:
                        self.stats["skipped"] += 1
                    elif is_edit:
                        self.handle_edit(src_chat_id, ch, int(msg["message_id"]), content)
                    elif msg.get("media_group_id") and content.kind in ("photo", "video"):
                        self._album_add(f"{src_chat_id}:{msg['media_group_id']}", ch,
                                        src_chat_id, int(msg["message_id"]), content)
                    else:
                        self.handle_new(src_chat_id, ch, int(msg["message_id"]), content)
                    self.state.offset = uid + 1  # confirm update
                except Exception as e:
                    log.exception("unexpected error on update %s: %s", u.get("update_id"), e)

            self._flush_albums()

            # v1.1 hotfix: Bale vote poll AFTER user-facing processing —
            # a slow/blocked Bale must never hold incoming commands hostage.
            self._handle_bale_callbacks()

            # v1.1: periodic license re-check (cheap, guarded by interval)
            if time.monotonic() - last_guard >= 300:
                self._license_guard()
                last_guard = time.monotonic()

            if time.monotonic() - last_save >= cfg.save_interval:
                self.state.save()
                last_save = time.monotonic()

        self._flush_albums(force=True)
        self.state.save()
        self._pool.shutdown(wait=True)
        dead = len(self.state.data.get("dead", []))
        log.info("🏁 stop. posted=%(posted)d edited=%(edited)d skipped=%(skipped)d "
                 "failed=%(failed)d deleted=%(deleted)d | dead_list=%d", self.stats, dead)
        if dead:
            log.warning("⚠️  %d items on the dead-list — check state.json > dead", dead)


# --------------------------------------------------------------------- #
# Boot
# --------------------------------------------------------------------- #

_STOP = False


def _sig_handler(signum, frame):  # noqa: ARG001
    global _STOP
    log.info("🛑 signal %s received — finishing current step…", signum)
    _STOP = True


def _load_env_file() -> None:
    """Read KEY=VALUE lines from a config.env (working dir first, then /opt/armatcher).

    Existing environment variables always win (systemd EnvironmentFile support).
    """
    for p in (Path("config.env"), Path("/opt/armatcher/config.env")):
        if not p.exists():
            continue
        try:
            for ln in p.read_text(encoding="utf-8").splitlines():
                ln = ln.strip()
                if not ln or ln.startswith("#") or "=" not in ln:
                    continue
                k, v = ln.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v
            log.info("🔧 config loaded from %s", p)
            return
        except OSError as e:
            log.warning("⚠️  could not read %s: %s", p, e)


def main() -> None:
    signal.signal(signal.SIGTERM, _sig_handler)
    signal.signal(signal.SIGINT, _sig_handler)
    _load_env_file()
    cfg = Config()
    if _tombstone_path(cfg.state_file).exists():          # v1.1: /remoke stays dead
        log.error("🔴 remoke tombstone present — service stays OFF by vendor order")
        sys.exit(0)
    Relay(cfg).run()


if __name__ == "__main__":
    main()
