#!/usr/bin/env bash
# ============================================================
# ARMATCHER-GH v1.1 — autopilot installer (Ubuntu 24.04 VPS)
# Creates /opt/armatcher, a venv, a hardened build (source .py is
# compiled to bytecode and then REMOVED), and a systemd service.
# Usage as root:  bash install.sh
# ============================================================
set -euo pipefail

APP="/opt/armatcher"
CONF_DIR="/etc/armatcher"
CONF="${CONF_DIR}/config.env"
SERVICE="/etc/systemd/system/armatcher.service"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$(id -u)" != "0" ]; then
  echo "لطفاً با روت اجرا کن (sudo -i) / run as root." >&2
  exit 1
fi

echo "▶ [۱/۷] آماده‌سازی سیستم…"
export DEBIAN_FRONTEND=noninteractive
if ! python3 -m venv --help >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y python3-venv python3-full >/dev/null
fi
python3 --version

echo "▶ [۲/۷] ساخت مسیر برنامه در ${APP} …"
mkdir -p "$APP"
mkdir -p "$CONF_DIR"

echo "▶ [۳/۷] محیط مجازی و وابستگی‌ها…"
if [ ! -x "${APP}/venv/bin/python" ]; then
  python3 -m venv "${APP}/venv"
fi
"${APP}/venv/bin/pip" install --quiet --upgrade pip
"${APP}/venv/bin/pip" install --quiet requests

echo "▶ [۴/۷] نصب موتور (بیلد سخت‌گیرانه: سورس به بایت‌کد تبدیل و حذف می‌شود)…"
cp "${HERE}/relay.py" "${APP}/relay.py"
PYTAG="$("${APP}/venv/bin/python" - <<'PY'
import sys
print(f"cpython-{sys.version_info.major}{sys.version_info.minor}")
PY
)"
( cd "$APP" && venv/bin/python -m py_compile relay.py )
mv "${APP}/__pycache__/relay.${PYTAG}.pyc" "${APP}/relay.pyc"
rm -f "${APP}/relay.py"
rm -rf "${APP}/__pycache__"
chmod 640 "${APP}/relay.pyc"

echo "▶ [۵/۷] پیکربندی ${CONF} …"
if [ ! -f "$CONF" ]; then
  echo "  برای راه‌اندازی به ۴ مقدار نیاز است (توکن‌ها فقط در همین سرور می‌مانند):"
  read -r -s -p "  🔑 TELEGRAM_BOT_TOKEN: " TG_TOK; echo
  read -r -s -p "  🔑 BALE_BOT_TOKEN: " BALE_TOK; echo
  read -r -s -p "  🔑 RUBIKA_BOT_TOKEN: " RB_TOK; echo
  read -r -p "  👤 MAIN_ADMIN_ID (آیدی عددی ادمین اصلی): " MAIN_ID
  umask 077
  cat > "$CONF" <<EOF
TELEGRAM_BOT_TOKEN=${TG_TOK}
BALE_BOT_TOKEN=${BALE_TOK}
RUBIKA_BOT_TOKEN=${RB_TOK}
MAIN_ADMIN_ID=${MAIN_ID}
STATE_FILE=${APP}/state.json
POLL_TIMEOUT=25
SAVE_INTERVAL=30
EOF
  chmod 600 "$CONF"
  echo "  ✅ پیکربندی ذخیره شد (دسترسی ۶۰۰)."
else
  echo "  ℹ️ پیکربندی قبلی حفظ شد."
fi

echo "▶ [۶/۷] سرویس systemd …"
cat > "$SERVICE" <<EOF
[Unit]
Description=ARMATCHER Relay (GH edition)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${APP}
EnvironmentFile=${CONF}
ExecStart=${APP}/venv/bin/python ${APP}/relay.pyc
Restart=always
RestartSec=3
StartLimitIntervalSec=90
StartLimitBurst=6
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now armatcher

echo "▶ [۷/۷] وضعیت:"
sleep 2
systemctl --no-pager --full status armatcher | head -n 12 || true

echo
echo "✅ نصب تمام شد."
echo "   • لاگ زنده:   journalctl -u armatcher -f"
echo "   • خاموش/روشن: systemctl stop armatcher  |  systemctl start armatcher"
echo "   • ربات را در تلگرام /start کن و از کیبورد پایین، کانال‌ها را اضافه کن."
